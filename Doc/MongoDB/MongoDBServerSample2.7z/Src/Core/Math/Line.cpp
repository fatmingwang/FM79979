#include "../stdafx.h"
#include "Line.h"

namespace FATMING_CORE
{

//end namespace FATMING_CORE
}