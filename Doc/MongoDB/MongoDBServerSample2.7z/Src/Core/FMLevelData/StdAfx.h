#include "../../Core/AllCoreInclude.h"
#include "../../Core/FMEvent/AllEventInclude.h"
#include "../../Core/FatmingAI/AllFatmingAIInclude.h"
#include "string.h"