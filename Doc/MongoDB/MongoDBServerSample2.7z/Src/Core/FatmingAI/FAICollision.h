#ifndef _FAI_COLLISION_H_
#define _FAI_COLLISION_H_

namespace FATMING_AI
{

}

#endif