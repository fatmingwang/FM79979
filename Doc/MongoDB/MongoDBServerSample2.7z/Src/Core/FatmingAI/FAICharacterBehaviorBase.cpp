#include "stdafx.h"
#include "FAICharacterBehaviorBase.h"

//
//cFAICharacterBehaviorBase::cFAICharacterBehaviorBase(TiXmlElement*e_pTiXmlElement):cAIMachine(e_pTiXmlElement)
//{
//
//}
//
//cFAICharacterBehaviorBase::cFAICharacterBehaviorBase(cFAICharacterBehaviorBase*e_pCharacterBase):cAIMachine(e_pCharacterBase)
//{
//
//}
//
//cFAICharacterBehaviorBase::~cFAICharacterBehaviorBase()
//{
//
//}
//
//void	cFAICharacterBehaviorBase::Update(float e_fElpaseTime)
//{
//
//}
//
//void	cFAICharacterBehaviorBase::Render()
//{
//
//}