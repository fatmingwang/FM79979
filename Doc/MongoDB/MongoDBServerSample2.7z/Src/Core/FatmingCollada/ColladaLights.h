#ifndef COLLADA_LIGHTS_H
#define COLLADA_LIGHTS_H
#endif