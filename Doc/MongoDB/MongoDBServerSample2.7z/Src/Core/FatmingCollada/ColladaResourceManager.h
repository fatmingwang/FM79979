#ifndef COLLADA_RESOURCE_MANAGER_H
#define COLLADA_RESOURCE_MANAGER_H

//class	cMwshManager:,public cNamedTypedObjectVector<cMash*>;public:NamedTypedObject
//{
//	
//};

#endif