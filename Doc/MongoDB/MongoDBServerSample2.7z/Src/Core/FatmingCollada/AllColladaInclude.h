#ifndef ALL_COLLADA_INCLUDE_H
#define ALL_COLLADA_INCLUDE_H
#include "ColladaAnimations.h"
#include "ColladaCameras.h"
#include "ColladaEffects.h"
#include "ColladaGeometries.h"
#include "ColladaImages.h"
#include "ColladaLights.h"
#include "ColladaParser.h"
#include "ColladaMaterials.h"
#include "ColladaVisualScene.h"
#endif