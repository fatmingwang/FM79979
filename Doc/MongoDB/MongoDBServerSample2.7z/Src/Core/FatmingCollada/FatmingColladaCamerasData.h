#ifndef FATMING_COLLADA_CAMERA_DATA_H
#define FATMING_COLLADA_CAMERA_DATA_H

//struct
//{
//
//};

#endif