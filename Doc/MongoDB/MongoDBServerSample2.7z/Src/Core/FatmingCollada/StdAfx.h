#include "../AllCoreInclude.h"
extern std::vector<std::string>	*g_strParsingDataList;

#if defined(WIN32)
#elif defined(ANDROID)
 //#include <cstdarg>
#elif defined(IOS)

//#ifndef IOS
//#define	IOS
//#endif

#endif