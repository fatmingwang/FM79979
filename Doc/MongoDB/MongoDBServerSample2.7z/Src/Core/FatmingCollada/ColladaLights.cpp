#include "StdAfx.h"
#include "ColladaLights.h"