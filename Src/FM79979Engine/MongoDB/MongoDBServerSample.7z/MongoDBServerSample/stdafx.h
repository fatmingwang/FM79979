#pragma once

#include "windows.h"
#include "../Core/AllCoreInclude.h"
#include "UseBluetoothDoCodeReportParameter/UseBluetoothDoCodeReportParameter.h"
#include "LogID.h"