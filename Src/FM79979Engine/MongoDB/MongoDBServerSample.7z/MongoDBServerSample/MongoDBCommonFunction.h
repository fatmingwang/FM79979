#pragma once
#include "MongoDBHeader.h"
#include "FishDBStructer.h"

bool	GetElementValue(bsoncxx::v_noabi::document::view&e_View, const char*e_strFieldName, std::string&e_OutValue, bool e_bWriteLogIfFailed = true);
bool	GetElementValue(bsoncxx::v_noabi::document::view&e_View, const char*e_strFieldName, int &e_OutValue, bool e_bWriteLogIfFailed = true);
bool	GetElementValue(bsoncxx::v_noabi::document::view&e_View, const char*e_strFieldName, int64 &e_OutValue, bool e_bWriteLogIfFailed = true);


bool	GetArrayValue(bsoncxx::v_noabi::document::view&e_View, const char*e_strFieldName, std::vector<std::string> &e_OutValueVector, bool e_bWriteLogIfFailed = true);
bool	GetArrayValue(bsoncxx::v_noabi::document::view&e_View, const char*e_strFieldName, std::vector<int> &e_OutValueVector, bool e_bWriteLogIfFailed = true);
bool	GetArrayValue(bsoncxx::v_noabi::document::view&e_View, const char*e_strFieldName, std::vector<int64> &e_OutValueVector, bool e_bWriteLogIfFailed = true);
bool	GetArrayValue(bsoncxx::v_noabi::document::view&e_View, const char*e_strFieldName, std::vector<sReportInfoWithReportCodes> &e_OutValueVector, bool e_bWriteLogIfFailed = true);



struct sMongoDBUpdateResult
{
	sMongoDBUpdateResult(const mongocxx::v_noabi::result::bulk_write e_Result)
	{
		imatched_count = e_Result.matched_count();
		imodified_count = e_Result.modified_count();
		ideleted_count = e_Result.deleted_count();
		iupserted_count = e_Result.upserted_count();
		upserted_ids = e_Result.upserted_ids();
		inserted_count = e_Result.inserted_count();
	}
	int		imatched_count;
	int		imodified_count;
	int		ideleted_count;
	int		iupserted_count;
	int		inserted_count;
	mongocxx::v_noabi::result::bulk_write::id_map	upserted_ids;
	bool	IsMatchedAndModifedSameCount(int e_iExpectCount)
	{
		if (imatched_count == imodified_count && imatched_count == e_iExpectCount)
		{
			return true;
		}
		return false;
	}
};