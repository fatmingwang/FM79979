#pragma once

#include <locale>
#include <utility>
#include <codecvt>
#include "SrcDBServerSrcMongoDBServerFishGameParameterize/FishGameParameterize.h"

enum eUserAuthority
{
	eUA_WAIT_FOR_AUTHORIZE = 0,
	eUA_COMMON_USER,
	eUA_ADMIN,
	eUA_MAX
};

struct sMachineData
{
	//int	iMachineNumber;
	//int	iProductTypeNumber;
	int	iTWLeadStreamMachineNumber;
};

struct sUserDataInUserCollection
{
	std::string					strID;
	std::string					strPWD;
	std::string					strDescription;//wstring to string
	eUserAuthority				m_eUserAuthority;
	std::vector<sMachineData>	OwnMachineVector;
	std::map<int, std::vector<struct sReportInfoWithReportCodes> >	m_MachineIDAndReportInfoMap;
	int							GetMachineIndex(int e_iMachineID)
	{
		auto l_Size = OwnMachineVector.size();
		for (size_t i = 0; i < l_Size; ++i)
		{
			if (e_iMachineID == OwnMachineVector[i].iTWLeadStreamMachineNumber)
				return (int)i;
		}
		return -1;
	}
	bool						ComparePassword(const char*e_strPassword)
	{
		if (strPWD.compare(e_strPassword) == 0)
		{
			return true;
		}
		return false;
	}
};
//User Collection
//"Name:string"
//"PWD:string"
//"Description:string"
//OwnMachine-object array
//{
//	MachineData: 
//	{
//		"MachineID:int"
//		"ProductTypeNumber:int"
//		"iTWLeadStreamMachineNumber:int"
//	}
//}
//Authority:int

//User MachineHistory Collection
//MachineReportHistory-Object array
//
//MachineReportHistory
//{
//	TWLeadStreamID - int
//	sReportInfoWithParameters - object array
//}

struct sReportInfoWithReportCodes:public sReportInfo
{
	std::string	strVersion;
	char		strReportCode[50];
	sReportInfoWithReportCodes()
	{
		memset(this, 0, sizeof(sReportInfoWithReportCodes));
	}
};

//struct sMachineReportHistory
//{
//	int iTWLeadStreamMachineNumber;
//	std::vector<sReportInfoWithReportCodes>	m_ReportInfoWithReportCodesVector;
//};

//key for TELeadStream ID
typedef std::map<int, std::vector<sReportInfoWithReportCodes> >	TWLeadStreamMachineIDAndReportInfoVectorMap;

inline std::string STDWStringToString(std::wstring e_String)
{
	std::wstring_convert<std::codecvt_utf8_utf16<wchar_t>> converter;
	std::string narrow = converter.to_bytes(e_String);
	return narrow;
}

inline std::wstring STDStringToWString(std::string e_String)
{
	std::wstring_convert<std::codecvt_utf8_utf16<wchar_t>> converter;
	std::wstring wide = converter.from_bytes(e_String);
	return wide;
}

