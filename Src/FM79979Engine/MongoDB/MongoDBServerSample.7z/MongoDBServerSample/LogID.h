#pragma once


#define	LOG_ID_MONGO_DB	1
#define	LOG_ID_NETWORK	2
#define	LOG_ID_USER		3