#include "stdafx.h"
#include "MongoDB.h"
#include "User.h"
#include "EventMessage.h"
#include "MongoDBCommonFunction.h"
#include "DBFieldName.h"

#include <locale>
#include <codecvt>
#include <string>


bool cMongoDB::UserDataProcess(bsoncxx::v_noabi::document::view&e_View, sUserDataInUserCollection&e_UserDataInUserCollection)
{
	sUserDataInUserCollection l_UserDataInUserCollection;
	try
	{
		//bsoncxx::v_noabi::type l_Type = l_strDescription.type();
		bsoncxx::v_noabi::document::element l_ElementDescription = e_View[DESCRIPTION];
		std::string l_strID;
		std::string l_strPWD;
		std::string l_strDescription;
		int			l_iAuthority;
		if (!GetElementValue(e_View, USER_ID, l_strID) ||
			!GetElementValue(e_View, PASSWORD, l_strPWD) ||
			!GetElementValue(e_View, DESCRIPTION, l_strDescription) ||
			!GetElementValue(e_View, "Authority", l_iAuthority))
		{
			return false;
		}
		FMLog::LogWithFlag(UT::ComposeMsgByFormat("cMongoDB::UserDataProcess:start to parse %s", l_strID.c_str()).c_str(), LOG_ID_MONGO_DB, true);
		std::vector<int>	l_MachineIDVector;
		if (GetArrayValue(e_View, MACHINELIST, l_MachineIDVector, true))
		{
			for (size_t i = 0; i < l_MachineIDVector.size(); ++i)
			{
				sMachineData l_MachineData;
				l_MachineData.iTWLeadStreamMachineNumber = l_MachineIDVector[i];
				l_UserDataInUserCollection.OwnMachineVector.push_back(l_MachineData);
			}
		}
		//find all report information
		auto l_pUserIDCollection = m_FishDatabase[l_strID.c_str()];
		mongocxx::cursor l_Cursor = l_pUserIDCollection.find({});
		for (auto l_View : l_Cursor)
		{
			UserReportInfoDataProcess(l_View, e_UserDataInUserCollection);
		}
		l_UserDataInUserCollection.m_eUserAuthority = (eUserAuthority)l_iAuthority;
		l_UserDataInUserCollection.strID = l_strID;
		l_UserDataInUserCollection.strPWD = l_strPWD;
		l_UserDataInUserCollection.strDescription = l_strDescription;
		e_UserDataInUserCollection = l_UserDataInUserCollection;
		return true;
	}
	catch (std::exception e)
	{
		std::string l_str = "Error Exception cMongoDB::UserDataProcess failed:";
		l_str += e.what();
		FMLog::LogWithFlag(l_str.c_str(), LOG_ID_MONGO_DB, true);
	}
	return false;
}

bool	cMongoDB::UserReportInfoDataProcess(bsoncxx::v_noabi::document::view&e_View, sUserDataInUserCollection&e_UserDataInUserCollection)
{
	int l_iMachineID = 0;
	if (GetElementValue(e_View, MACHINE_ID, l_iMachineID))
	{
		std::string l_strBehaviorMessage = UT::ComposeMsgByFormat("%d try to add report info", l_iMachineID);
		std::vector<sReportInfoWithReportCodes> l_OutValueVector;
		if (GetArrayValue(e_View, MACHINE_REPORT_DATA_ARRAY, l_OutValueVector))
		{
			auto l_Iterator = e_UserDataInUserCollection.m_MachineIDAndReportInfoMap.find(l_iMachineID);
			if (l_Iterator == e_UserDataInUserCollection.m_MachineIDAndReportInfoMap.end())
			{
				e_UserDataInUserCollection.m_MachineIDAndReportInfoMap.insert(std::make_pair(l_iMachineID, l_OutValueVector));
				l_strBehaviorMessage += ",info count is ";
				l_strBehaviorMessage += ValueToString(l_OutValueVector.size());
				FMLog::LogWithFlag(l_strBehaviorMessage.c_str(), LOG_ID_MONGO_DB, true);
				return true;
			}
			else
			{
				std::string l_strLog = "Error:same machie ID should't add report info at different document!";
				l_strLog += l_strBehaviorMessage;
				FMLog::LogWithFlag(l_strLog.c_str(), LOG_ID_MONGO_DB, true);
			}
		}
		else
		{
			std::string l_strLog = "Error:get report info vector failed!";
			l_strLog += l_strBehaviorMessage;
			FMLog::LogWithFlag(l_strLog.c_str(), LOG_ID_MONGO_DB, true);
		}
	}
	else
	{
		FMLog::LogWithFlag("cMongoDB::UserReportInfoDataProcess dont caontain MACHINE_ID", LOG_ID_MONGO_DB, true);
	}
	return false;
}