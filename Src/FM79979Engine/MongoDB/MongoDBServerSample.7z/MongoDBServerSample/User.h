#pragma once

#include "../Core/Network/GameNetWork.h"
#include "FishDBStructer.h"

template<class USER_DATA>
class cDBUserData :public NamedTypedObject
{
	friend class cUserVector;
	//
	TWLeadStreamMachineIDAndReportInfoVectorMap	m_TWLeadStreamMachineIDAndReportInfoVectorMap;
	std::vector<int>							m_OwnMachineTWLeadStreamMachineIDVector;
	float										m_fCodeReportAppVersion;
	USER_DATA									m_UserDataInUserCollection;
	bool										m_bLogin;
	_TCPsocket*									m_pSocket;
	void	SetLogin(bool e_bLogin, _TCPsocket*e_pSocket)
	{
		m_bLogin = e_bLogin;
		m_pSocket = e_pSocket;
	}
public:
	cDBUserData(const USER_DATA e_UserDataInUserCollection)
	{
		m_pSocket = nullptr;
		m_bLogin = false;
		m_UserDataInUserCollection = e_UserDataInUserCollection;
		this->SetName(m_UserDataInUserCollection.strID.c_str());
	}
	virtual ~cDBUserData(){}
	_TCPsocket*GetSocket() {return m_pSocket;}
	bool	IsLogin() { return m_bLogin; }
	USER_DATA &GetUserData() { return m_UserDataInUserCollection; }
};

typedef cDBUserData<sUserDataInUserCollection> cUser;

class cUserVector:public cNamedTypedObjectVector<cUser>,public cMessageSender, public cSingltonTemplate<cUserVector>
{
	std::map<_TCPsocket*, cUser*>	m_TCPSocketAndConnectedUserMap;
	//
public:
	cUserVector();
	virtual ~cUserVector();
	DEFINE_TYPE_INFO();
	SINGLETON_BASIC_FUNCTION(cUserVector);
	virtual void	Destroy()override;
	//
	cUser*			AddActivedConnectedUser(_TCPsocket*e_pSocket,const char*e_strID);
	cUser*			GetActivedConnectedUser(_TCPsocket*e_pSocket);
	bool			RemoveActivedConnectedUser(_TCPsocket*e_pSocket);
	//
	bool			UserAddNewMachineToDB(int e_iUserID, int e_iMachineID);
	bool			AddHostoryDataByMachineNumberToDB(int e_iUserID,int e_iMachineID, sReportInfoWithReportCodes e_ReportData);
	bool			AddUserToDB(std::wstring e_strUserName, eUserAuthority e_eUserAuthority);
	//
	static bool		AdminAuthorityCheck(cUser*e_pUser,std::string&e_strErrorMessage);
	static bool		AdminAuthorityAndTargetUserCheck(cUserVector*e_pUserVector,cUser*e_pUser,const char*e_strTargetID, std::string&e_strErrorMessage);
	//
	//cConnectedUser*	GetObjectByID(int e_iID);
	std::mutex		Instancem_Mutex;
};

#define	GET_USER_VECTOR_INSTANCE_AND_DO_MUTEX(Instance_Name)	cUserVector*Instance_Name = cUserVector::GetInstance(); MUTEX_PLACE_HOLDER(Instance_Name->Instancem_Mutex);