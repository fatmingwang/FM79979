#ifdef WIN32
#include "stdafx.h"
#else
#include "../../Core/AllCoreInclude.h"
#endif
#include "FishGameParameterize.h"

namespace FISG_GAME_PARAMETERIZE
{
	const int g_iReportCodeSaveCodeLength_V_1_4 = 3;
	const int g_iMinimumReportCodeLazyMagicNumber_V_1_4 = 123456;
	const int g_iReportCodeLazyMagicNumber_V_1_4 = 79979;
	const int g_iMaxMagicXORDataCount_V_1_4 = 16;
	#define	GET_MINIMUN_REPORT_CODE_LAZY_MAGIC_NUMBER_STRING_LENGTH_V_1_4(V) strlen(#V)
	const char* g_strMagicXORData_V_1_4[g_iMaxMagicXORDataCount_V_1_4] = {
		"123456789016548709876346354652",
		"127986540679876749687946540662",
		"1798065467498765430465464654961",
		"1287987654608706546074987406541",
		"987064987654032169579607895090",//5
		"123457460687968465046543255090",
		"987654067684654698435465465490",
		"187876798765403216878086545090",
		"787878979879685087987654034221",
		"987563540574987604659878967890",//10
		"128798065460543218709876540890",
		"120789450465498473241654056090",
		"120897654032487034608765480090",
		"120897065403210878987985664090",
		"989879803621054873254087630090",//15
		"123456789012345678901234567890"
	};
	//only allow 5 numbers
	int64	GenerateReportCodeMagicNumber_V_1_4(uint64 e_i64ExchangeIn, uint64 e_i64ExchangeOut, uint64 e_iBulletCount, int e_iReportCount, sTwLeadStreamProductData e_sTwLeadStreamProductData)
	{
		const int l_iValueToStringLength = (int)GET_MINIMUN_REPORT_CODE_LAZY_MAGIC_NUMBER_STRING_LENGTH_V_1_4(g_iMinimumReportCodeLazyMagicNumber);
		int64 l_i64Value = ((e_i64ExchangeIn + e_i64ExchangeOut + e_iBulletCount)*(e_iReportCount)) + e_sTwLeadStreamProductData.GetTwLeadStreamProductDataNumber();
		l_i64Value += g_iReportCodeLazyMagicNumber_V_1_4;
		auto l_strValue = ValueToString(l_i64Value);
		int l_iLength = (int)l_strValue.length();
		if (l_iLength > l_iValueToStringLength)
		{
			l_strValue.erase(l_iValueToStringLength, l_iLength - l_iValueToStringLength);
		}
		l_i64Value = GetInt64(l_strValue.c_str());
		return l_i64Value;
	}

	bool	GenerateReportCodeWithXor_V_1_4(char*e_strReportCodeOutData, int64 e_i64MagixNumber, int e_iRandomValue)
	{
		int l_iSafeCountToCopy = REPORT_CODE_LENGTH - g_iReportCodeSaveCodeLength_V_1_4;//1 for random value
		int64 l_i64Total = e_i64MagixNumber;
		auto l_strTotal = ValueToString(l_i64Total);
		int l_iRandomValue = e_iRandomValue;
		int l_iTotalNumberToStringLength = (int)l_strTotal.length();
		e_strReportCodeOutData[0] = l_iRandomValue + '0';
		e_strReportCodeOutData[1] = rand() % 10 + '0';
		e_strReportCodeOutData[2] = rand() % 10 + '0';
		auto l_strXORCode = g_strMagicXORData_V_1_4[l_iRandomValue];
		int l_iCount = (int)l_strTotal.length() + g_iReportCodeSaveCodeLength_V_1_4;
		if (l_iCount > l_iSafeCountToCopy)
			l_iCount = l_iSafeCountToCopy;
		const int l_ciStartBufferIndex = g_iReportCodeSaveCodeLength_V_1_4;
		//to fill buffer
		int	l_iIndex = 0;
		for (int i = l_ciStartBufferIndex; i < REPORT_CODE_LENGTH; i += 2)
		{
			int l_iData = l_strTotal[l_iIndex] ^ l_strXORCode[l_iIndex];
			e_strReportCodeOutData[i] = l_iData / 10 + '0';
			e_strReportCodeOutData[i + 1] = l_iData % 10 + '0';
			++l_iIndex;
		}
		return true;
	}

	bool GenerateReportCode_V_1_4(char * e_strReportCodeOutData, uint64 e_i64ExchangeIn, uint64 e_i64ExchangeOut, uint64 e_iBulletCount, int e_iReportCount, sTwLeadStreamProductData e_sTwLeadStreamProductData)
	{
		int64 l_i64Total = GenerateReportCodeMagicNumber_V_1_4(e_i64ExchangeIn, e_i64ExchangeOut, e_iBulletCount, e_iReportCount, e_sTwLeadStreamProductData);
		if (l_i64Total < 0)
			l_i64Total *= -1;
		uint64 l_iRandomValue = l_i64Total % 10;//for show deciaml
		GenerateReportCodeWithXor_V_1_4(e_strReportCodeOutData, l_i64Total, (int)l_iRandomValue);
		return true;
	}
	bool CompareReportCode_V_1_4(const char * e_strReportCode, const char * e_strPlayerInputReportCodeResult)
	{
		return false;
	}
}