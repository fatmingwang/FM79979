#ifdef WIN32
#include "stdafx.h"
#else
#include "../../Core/AllCoreInclude.h"
#endif
#include "FishGameParameterize.h"
namespace FISG_GAME_PARAMETERIZE
{
	//hex coding report
	#define	EXCHANGE_IN_EXCEED_BIT			0
	#define	EXCHANGE_OUT_EXCEED_BIT			1
	#define	BULLET_SHOOT_AMOUNT_EXCEED_BIT	2
	#define	REPORT_COUNT_EXCEED_BIT			3
	#define	MAGIC_ID_BIT					4
	#define	DEFAULT_MAGIC_XOR_INDEX			0
	#define	AVOID_HACK_BULLET_AMOUNT		5000
	//
	const int g_iMaxMagicXORDataCount = 16;
	const int g_iReportCodeSaveCodeLength = 3;
	const int g_iReportCodeLazyMagicNumber = 79979;
	const int g_iMinimumReportCodeLazyMagicNumber = 123456;
	#define	GET_MINIMUN_REPORT_CODE_LAZY_MAGIC_NUMBER_STRING_LENGTH(V) strlen(#V)
	const char* g_strMagicXORData[g_iMaxMagicXORDataCount] = {
		"123456789016548709876346354652",
		"127986540679876749687946540662",
		"1798065467498765430465464654961",
		"1287987654608706546074987406541",
		"987064987654032169579607895090",//5
		"123457460687968465046543255090",
		"987654067684654698435465465490",
		"187876798765403216878086545090",
		"787878979879685087987654034221",
		"987563540574987604659878967890",//10
		"128798065460543218709876540890",
		"120789450465498473241654056090",
		"120897654032487034608765480090",
		"120897065403210878987985664090",
		"989879803621054873254087630090",//15
		"123456789012345678901234567890"
	};
	const char* g_strTimeMagicXORDataArray[g_iMaxMagicXORDataCount] = {
		"126546587907345678901234567890",
		"126546879806546548901234567890",
		"126987879806546549801234567890",
		"126987879806546549801234567890",
		"129987879806546549801234567890",//5
		"129987056465749879801234567890",
		"129987056465749879801234567890",
		"129789079876545678901234567890",
		"123789079806546323145684567890",
		"198789079806546323145684567890",//10
		"145607898465546323145684567890",
		"145607898465546323145684567890",
		"945607898465546323145683456789",
		"945607898465234567890123456789",
		"945607898465234567890123456789",//15
		"987654607891234567890123456789"
	};
	int	GetMagicXorIndexWithTwLeadStreamProductData(int e_iIndex, sTwLeadStreamProductData*e_pTwLeadStreamProductData)
	{
		int iProductTypeNumber = e_pTwLeadStreamProductData->iProductTypeNumber;
		if (iProductTypeNumber == 0)
			iProductTypeNumber = 1;
		int l_iMachineID = e_pTwLeadStreamProductData->iMachineID;
		if (l_iMachineID == 0)
			l_iMachineID = 1;
		int l_iMagicID = (e_iIndex + iProductTypeNumber + l_iMachineID) % g_iMaxMagicXORDataCount;
		return l_iMagicID;
	}
	//e_iRandomValue cannt excee 16
	bool GetXOrCodeByTwLeadStreamProductData(char*e_pOutMagixXorData,int e_iExpectLength, sTwLeadStreamProductData*e_pTwLeadStreamProductData,int e_iRandomValue,int64 e_i64BulletShootAmount)
	{
		if (e_iExpectLength > REPORT_CODE_LENGTH)
		{
			for (int i = 0; i < e_iExpectLength; i++)
			{
				e_pOutMagixXorData[i] = '1';
			}
			assert(0&&"GetXOrCodeByTwLeadStreamProductData::e_iExpectLength over REPORT_CODE_LENGTH is not allow");
			return false;
		}
		int l_iIndex = e_iRandomValue;
		//to avoid someone try to hack.
		if (e_i64BulletShootAmount < AVOID_HACK_BULLET_AMOUNT || e_i64BulletShootAmount == -1)
		{
			l_iIndex = DEFAULT_MAGIC_XOR_INDEX;
		}
		int l_iMagicID = GetMagicXorIndexWithTwLeadStreamProductData(l_iIndex, e_pTwLeadStreamProductData);
		memcpy(e_pOutMagixXorData, g_strMagicXORData[l_iMagicID], e_iExpectLength);
		return true;
	}
	bool BigEndianMemcpy(char*e_pSrcData, char*e_pCopyToData, int e_iStartCopy, int e_iEndCopy)
	{
		int l_iSize = e_iEndCopy - e_iStartCopy;
		if (l_iSize < 1)
			return false;
		char*l_pTemp = new char[l_iSize];
		memcpy(l_pTemp, &e_pSrcData[e_iStartCopy], l_iSize);
		for (int i = 0; i < l_iSize; i++)
		{
			int l_iTargetIndex = l_iSize-1-i;
			e_pCopyToData[i] = l_pTemp[l_iTargetIndex];
		}
		delete[] l_pTemp;
		return true;
	}

	void GenerateFirstThreeCode(char*e_pOutData,
		uint64 &e_i64ExchangeIn,
		uint64 &e_i64ExchangeOut,
		uint64 &e_i64ShootBulletAmount,
		int e_iReportCount)
	{
		uint64 l_ui64AllowToEncriptenInt64Value = 0xffffffff;
		char* l_pcReportTime = e_pOutData;
		memset(l_pcReportTime, 0, sizeof(char) * 3);
		int l_iMagicXOr = 0;
		if (e_i64ShootBulletAmount < AVOID_HACK_BULLET_AMOUNT || e_i64ShootBulletAmount == -1)
			l_iMagicXOr = DEFAULT_MAGIC_XOR_INDEX;
		else
			l_iMagicXOr = rand() % g_iMaxMagicXORDataCount;
		bool l_bReportExceed0xfff = false;
		bool l_bExchangeInCoinExceed0xffffffff = false;
		bool l_bExchangeOutCoinExceed0xffffffff = false;
		bool l_bExchangeShootBulletAmountExceed0xffffffff = false;
		if (e_iReportCount > 0xffff)
		{
			l_bReportExceed0xfff = true;
			l_pcReportTime[0] |= 1 << REPORT_COUNT_EXCEED_BIT;
		}
		if (e_i64ExchangeIn > l_ui64AllowToEncriptenInt64Value)
		{
			l_bExchangeInCoinExceed0xffffffff = true;
			l_pcReportTime[0] |= 1 << EXCHANGE_IN_EXCEED_BIT;
		}
		if (e_i64ExchangeOut > l_ui64AllowToEncriptenInt64Value)
		{
			l_bExchangeOutCoinExceed0xffffffff = true;
			l_pcReportTime[0] |= 1 << EXCHANGE_OUT_EXCEED_BIT;
		}
		if (e_i64ShootBulletAmount > l_ui64AllowToEncriptenInt64Value)
		{
			l_bExchangeShootBulletAmountExceed0xffffffff = true;
			l_pcReportTime[0] |= 1 << BULLET_SHOOT_AMOUNT_EXCEED_BIT;
		}
		l_pcReportTime[0] |= l_iMagicXOr << MAGIC_ID_BIT;
		short*l_pReportTime = (short*)&l_pcReportTime[1];
		*l_pReportTime = (short)e_iReportCount;
	}

	bool	GetTimeUpResultData(char*l_pOutData,sTwLeadStreamProductData e_sTwLeadStreamProductData,
		uint64 e_i64ExchangeIn,
		uint64 e_i64ExchangeOut,
		uint64 e_i64ShootBulletAmount,
		int e_iReportCount, char*e_pOriginalDataWithoutEncryption)
	{
		memset(l_pOutData, 0, sizeof(char) * REPORT_CODE_LENGTH);
		memset(e_pOriginalDataWithoutEncryption, 0, sizeof(char) * REPORT_CODE_LENGTH);
		unsigned char l_cFirst3Code[3];
		unsigned char l_cExchangeIn[4];
		unsigned char l_cExchangeOut[4];
		unsigned char l_cBulletShootAmount[4];
		GenerateFirstThreeCode((char*)l_cFirst3Code,e_i64ExchangeIn, e_i64ExchangeOut, e_i64ShootBulletAmount, e_iReportCount);
		int l_i64ExchangeIn = e_i64ExchangeIn%0xffffffff;
		int l_i64ExchangeOutCoin = e_i64ExchangeOut % 0xffffffff;;
		int l_i64ShootBulletAmount = e_i64ShootBulletAmount % 0xffffffff;;
		BigEndianMemcpy((char*)&l_i64ExchangeIn, (char*)l_cExchangeIn,0,4);
		BigEndianMemcpy((char*)&l_i64ExchangeOutCoin, (char*)l_cExchangeOut, 0, 4);
		BigEndianMemcpy((char*)&l_i64ShootBulletAmount, (char*)l_cBulletShootAmount, 0, 4);
		int l_iBufferIndex = 0;
		memcpy(&l_pOutData[l_iBufferIndex], l_cFirst3Code, sizeof(char) * 3);
		l_iBufferIndex += 3;
		memcpy(&l_pOutData[l_iBufferIndex], l_cExchangeIn, sizeof(char) * 4);
		l_iBufferIndex += 4;
		memcpy(&l_pOutData[l_iBufferIndex], l_cExchangeOut, sizeof(char) * 4);
		l_iBufferIndex += 4;
		memcpy(&l_pOutData[l_iBufferIndex], l_cBulletShootAmount, sizeof(char) * 4);

		int l_iMagicXorIndex = l_cFirst3Code[0] >> MAGIC_ID_BIT;
		char l_cXorData[REPORT_CODE_LENGTH];
		GetXOrCodeByTwLeadStreamProductData(l_cXorData, REPORT_CODE_LENGTH, &e_sTwLeadStreamProductData, l_iMagicXorIndex, e_i64ShootBulletAmount);
		//skip first to keep xor magic index.
		if (e_pOriginalDataWithoutEncryption)
			e_pOriginalDataWithoutEncryption[0] = l_pOutData[0];
		for (int i = 1; i < REPORT_CODE_LENGTH; i++)
		{
			if(e_pOriginalDataWithoutEncryption)
				e_pOriginalDataWithoutEncryption[i] = l_pOutData[i];
			l_pOutData[i] ^= l_cXorData[i];
		}
		return true;
	}

	bool	DecryptionTimeUpResultData(sTwLeadStreamProductData e_sTwLeadStreamProductData, char*e_pEncryptionData, char*e_pDecryptionData)
	{
		int l_iMagicXorIndex = (unsigned char)e_pEncryptionData[0] >> MAGIC_ID_BIT;
		char l_cXorData[REPORT_CODE_LENGTH];
		GetXOrCodeByTwLeadStreamProductData(l_cXorData, REPORT_CODE_LENGTH, &e_sTwLeadStreamProductData, l_iMagicXorIndex, AVOID_HACK_BULLET_AMOUNT);
		e_pDecryptionData[0] = e_pEncryptionData[0];
		for (int i = 1; i < REPORT_CODE_LENGTH; i++)
		{
			e_pDecryptionData[i] = e_pEncryptionData[i]^ l_cXorData[i];
		}
		return true;
	}

	bool	IsTimeUpResultDataMatch(sTwLeadStreamProductData e_sTwLeadStreamProductData, char*e_pDecrytionData,
		uint64 e_i64ExchangeIn,
		uint64 e_i64ExchangeOut,
		uint64 e_i64ShootBulletAmount)
	{
		char l_cExchangeIn[4];
		char l_cExchangeOut[4];
		char l_cShootBulletAmount[4];
		char l_cExchangeInFromDecrytion[4];
		char l_cExchangeOutFromDecrytion[4];
		char l_cShootBulletAmountFromDecrytion[4];
		memcpy(l_cExchangeInFromDecrytion, &e_pDecrytionData[3], 4);
		memcpy(l_cExchangeOutFromDecrytion, &e_pDecrytionData[7], 4);
		memcpy(l_cShootBulletAmountFromDecrytion, &e_pDecrytionData[11], 4);
		int l_i64ExchangeIn = e_i64ExchangeIn % 0xffffffff;
		int l_i64ExchangeOutCoin = e_i64ExchangeOut % 0xffffffff;;
		int l_i64ShootBulletAmount = e_i64ShootBulletAmount % 0xffffffff;;
		BigEndianMemcpy((char*)&l_i64ExchangeIn, (char*)l_cExchangeIn, 0, 4);
		BigEndianMemcpy((char*)&l_i64ExchangeOutCoin, (char*)l_cExchangeOut, 0, 4);
		BigEndianMemcpy((char*)&l_i64ShootBulletAmount, (char*)l_cShootBulletAmount, 0, 4);
		for (int i = 0; i < 4; i++)
		{
			if (l_cExchangeIn[i] != l_cExchangeInFromDecrytion[i] ||
				l_cExchangeOut[i] != l_cExchangeOutFromDecrytion[i] ||
				l_cShootBulletAmount[i] != l_cShootBulletAmountFromDecrytion[i])
				return false;
		}
		return true;
	}

	bool	GenerateTwLeadStreamMachineInitialSettingByTime(int e_iRandomIndex, char*e_pForPlayerInputData, int64 e_iTime)
	{
		memset(e_pForPlayerInputData, 0, REPORT_CODE_LENGTH);
		e_pForPlayerInputData[0] = e_iRandomIndex+'0';
		auto l_strTime = ValueToString(e_iTime);
		size_t l_uiSize = l_strTime.length();
		if (l_uiSize > REPORT_CODE_LENGTH)
			l_uiSize = REPORT_CODE_LENGTH;
		memcpy(&e_pForPlayerInputData[1], l_strTime.c_str(), sizeof(char) * l_uiSize);
		auto l_strMagicXORData = g_strTimeMagicXORDataArray[e_iRandomIndex];
		int l_iCount = (int)l_uiSize+1;
		for (int i = 1; i < l_iCount; i++)
		{
			e_pForPlayerInputData[i] ^= l_strMagicXORData[i];
		}
		for (size_t i = l_iCount; i < REPORT_CODE_LENGTH; i++)
		{
			e_pForPlayerInputData[i] ^= l_strMagicXORData[i];
		}
		return true;
	}

	int64	GetTimeFromTimeCode(char*e_strTimeCode)
	{
		char l_cCopyData[REPORT_CODE_LENGTH];
		memcpy(l_cCopyData,e_strTimeCode, REPORT_CODE_LENGTH);
		int64 l_i64CurrentTime = (int64)currentTimeInMilliseconds();
		auto l_strTime = ValueToString(l_i64CurrentTime);
		size_t l_uiSize = l_strTime.length();
		if (l_uiSize > REPORT_CODE_LENGTH)
			l_uiSize = REPORT_CODE_LENGTH;
		int l_iRandomValue = l_cCopyData[0]-'0';
		const char*l_strMagicXORData = g_strTimeMagicXORDataArray[l_iRandomValue];
		int l_iCount = (int)l_uiSize+1;
		for (int i = 1; i < l_iCount; i++)
		{
			l_cCopyData[i] ^= l_strMagicXORData[i];
		}
		char l_strOriginalTime[REPORT_CODE_LENGTH + 1];
		memcpy(l_strOriginalTime, &l_cCopyData[1], l_uiSize);
		l_strOriginalTime[l_uiSize] = 0;
		//get time offset
		int64 l_uiTimeCodeTime = GetInt64(l_strOriginalTime);
		return l_uiTimeCodeTime;
	}

	bool	MachineSeetingGenerateTimeCode(char*e_pOutTimeCodeData)
	{
		int64 l_i64CurrentTime = (int64)currentTimeInMilliseconds();
		int l_iRandomValue = rand() % 10;//because the number to show is dicimal.
		GenerateTwLeadStreamMachineInitialSettingByTime(l_iRandomValue, e_pOutTimeCodeData, l_i64CurrentTime);
		return true;
	}


	bool	MachineSeetingGenerateTimeCodeByTwLeadStreamMachineID(char*e_pOutTimeCodeData, char*e_pOutResultData, sTwLeadStreamProductData e_sTwLeadStreamProductData)
	{
		int64 l_i64Time = GetTimeFromTimeCode(e_pOutTimeCodeData);
		int l_iMachineDataTotal = e_sTwLeadStreamProductData.iMachineID+e_sTwLeadStreamProductData.iProductTypeNumber;
		l_iMachineDataTotal %= 10;//number to show is decimal
		GenerateTwLeadStreamMachineInitialSettingByTime(l_iMachineDataTotal, e_pOutResultData, l_i64Time);
		return true;
	}

	bool CompareTwLeadStreamMachineTimeCode(char*e_pPlayerInputData,char*e_strTimeCode, sTwLeadStreamProductData e_sTwLeadStreamProductData)
	{
		int64	l_i64Time1 = GetTimeFromTimeCode(e_pPlayerInputData);
		int64	l_i64Time2 = (int64)currentTimeInMilliseconds();
		//int64	l_i64Time2 = GetTimeFromTimeCode(e_strTimeCode);
		l_i64Time1 /= 1000;
		l_i64Time2 /= 1000;
		int64 l_i64TimeOffset = l_i64Time2-l_i64Time1;
		if (l_i64TimeOffset > 0 && l_i64TimeOffset < 300)//5 minutes
		{
			char l_cGetResultData[REPORT_CODE_LENGTH];
			MachineSeetingGenerateTimeCodeByTwLeadStreamMachineID(e_strTimeCode, l_cGetResultData, e_sTwLeadStreamProductData);
			for (int i = 0; i < REPORT_CODE_LENGTH; i++)
			{
				if (e_pPlayerInputData[i] != l_cGetResultData[i])
					return false;
			}
			return true;
		}
		return false;
	}
	//only allow 5 numbers
	int64	GenerateReportCodeMagicNumber(uint64 e_i64ExchangeIn, uint64 e_i64ExchangeOut,uint64 e_iBulletCount, int e_iReportCount, sTwLeadStreamProductData e_sTwLeadStreamProductData)
	{
		const int l_iValueToStringLength = (int)GET_MINIMUN_REPORT_CODE_LAZY_MAGIC_NUMBER_STRING_LENGTH(g_iMinimumReportCodeLazyMagicNumber);
		//if(strcmp(g_strFishGameParameterizeVersion,"1.2"))
		//{
		//	return -1;
		//}
		//if (e_sTwLeadStreamProductData.i64UniqueID == 0)
		//	return -2;
		int64 l_i64Value = ((e_i64ExchangeIn + e_i64ExchangeOut+ e_iBulletCount)*(e_iReportCount)) + e_sTwLeadStreamProductData.GetTwLeadStreamProductDataNumber();
		l_i64Value += g_iReportCodeLazyMagicNumber;
		//if ((e_i64ExchangeIn + e_i64ExchangeOut) < g_iMinimumReportCodeLazyMagicNumber)
		//{
		//	l_i64Value = g_iMinimumReportCodeLazyMagicNumber;
		//}
		auto l_strValue = ValueToString(l_i64Value);
		int l_iLength = (int)l_strValue.length();
		if (l_iLength > l_iValueToStringLength)
		{
			l_strValue.erase(l_iValueToStringLength, l_iLength - l_iValueToStringLength);
		}
		l_i64Value = GetInt64(l_strValue.c_str());
		return l_i64Value;
	}
	bool	GenerateReportCodeWithXor(char*e_strReportCodeOutData,int64 e_i64MagixNumber,int e_iRandomValue)
	{
		int l_iSafeCountToCopy = REPORT_CODE_LENGTH - g_iReportCodeSaveCodeLength;//1 for random value
		int64 l_i64Total = e_i64MagixNumber;
		auto l_strTotal = ValueToString(l_i64Total);
		int l_iRandomValue = e_iRandomValue;
		int l_iTotalNumberToStringLength = (int)l_strTotal.length();
		e_strReportCodeOutData[0] = l_iRandomValue + '0';
		e_strReportCodeOutData[1] = rand() % 10 + '0';
		e_strReportCodeOutData[2] = rand() % 10 + '0';
		auto l_strXORCode = g_strMagicXORData[l_iRandomValue];
		int l_iCount = (int)l_strTotal.length() + g_iReportCodeSaveCodeLength;
		if (l_iCount > l_iSafeCountToCopy)
			l_iCount = l_iSafeCountToCopy;
		const int l_ciStartBufferIndex = g_iReportCodeSaveCodeLength;
		//to fill buffer
		int	l_iIndex = 0;
		for (int i = l_ciStartBufferIndex; i < REPORT_CODE_LENGTH; i+=2)
		{
			int l_iData = l_strTotal[l_iIndex] ^ l_strXORCode[l_iIndex];
			e_strReportCodeOutData[i] = l_iData/10+'0';
			e_strReportCodeOutData[i+1] = l_iData%10+'0';
			++l_iIndex;
		}
		return true;
	}
	int GetRepornCodeRandomValue(int64 l_i64Total)
	{
		return l_i64Total % 10;//for show deciaml
	}
	//
	bool	GenerateReportCode_V_1_3(char*e_strReportCodeOutData, uint64 e_i64ExchangeIn, uint64 e_i64ExchangeOut, uint64 e_iBulletCount, int e_iReportCount, sTwLeadStreamProductData e_sTwLeadStreamProductData)
	{
		int64 l_i64Total = GenerateReportCodeMagicNumber(e_i64ExchangeIn, e_i64ExchangeOut, e_iBulletCount, e_iReportCount, e_sTwLeadStreamProductData);
		if (l_i64Total < 0)
			l_i64Total *= -1;
		uint64 l_iRandomValue = l_i64Total % 10;//for show deciaml
		return GenerateReportCodeWithXor(e_strReportCodeOutData, l_i64Total, (int)l_iRandomValue);
	}
	//
	bool	GenerateReportCode(char*e_strReportCodeOutData,uint64 e_i64ExchangeIn, uint64 e_i64ExchangeOut, uint64 e_iBulletCount, int e_iReportCount, sTwLeadStreamProductData e_sTwLeadStreamProductData)
	{
		if (!strcmp(g_strFishGameParameterizeVersion, "1.3"))
			return GenerateReportCode_V_1_3(e_strReportCodeOutData, e_i64ExchangeIn, e_i64ExchangeOut, e_iBulletCount, e_iReportCount, e_sTwLeadStreamProductData);
		else
		if (!strcmp(g_strFishGameParameterizeVersion, "1.4"))
			return GenerateReportCode_V_1_4(e_strReportCodeOutData, e_i64ExchangeIn, e_i64ExchangeOut, e_iBulletCount, e_iReportCount, e_sTwLeadStreamProductData);
		return false;
	}

	int64	ReportCodeToNumber(const char*e_strReportCodeOutData)
	{
		char l_cNumberBuffer[REPORT_CODE_LENGTH];
		int l_iRandomValue = e_strReportCodeOutData[0]-'0';
		memset(l_cNumberBuffer, 0, sizeof(l_cNumberBuffer));
		auto l_strXORCode = g_strMagicXORData[l_iRandomValue];
		int l_iIndex = 0;
		int l_iIndex2 = 0;
		for (int i = g_iReportCodeSaveCodeLength; i < REPORT_CODE_LENGTH; i+=2)
		{
			int l_iValue = (e_strReportCodeOutData[i]-'0') * 10;
			l_iValue += (e_strReportCodeOutData[i+1] - '0');
			l_iValue ^= l_strXORCode[l_iIndex2];

			l_cNumberBuffer[l_iIndex2] = l_iValue;
			l_iIndex += 2;
			++l_iIndex2;
		}
		int64 l_i64Value = GetInt64(l_cNumberBuffer);
		return l_i64Value;
	}

	bool	GenerateReportCodeResult(char*e_strReportCodeOutData,char*e_strReportCodeResult,sTwLeadStreamProductData e_sTwLeadStreamProductData)
	{
		int64	l_i64Value = ReportCodeToNumber(e_strReportCodeOutData);
		int l_iRandomValue = (e_sTwLeadStreamProductData.iMachineID+ e_sTwLeadStreamProductData.iProductTypeNumber) % 10;
		GenerateReportCodeWithXor(e_strReportCodeResult, l_i64Value, l_iRandomValue);
		//for debug check
		//int64	l_i64Value2 = ReportCodeToNumber(e_strReportCodeResult);
		return true;
	}

	bool	CompareReportCode_V_1_3(const char*e_strReportCode, const char*e_strPlayerInputReportCodeResult)
	{
		int64	l_i64Value1 = ReportCodeToNumber(e_strReportCode);
		char	l_cReportCode[REPORT_CODE_LENGTH + 1];
		memcpy(l_cReportCode, e_strPlayerInputReportCodeResult, REPORT_CODE_LENGTH);
		l_cReportCode[REPORT_CODE_LENGTH] = 0;
		int64	l_i64Value2 = ReportCodeToNumber(l_cReportCode);
		//if(l_i64Value1 == l_i64Value2 && GetRepornCodeRandomValue(l_i64Value2) == GetRepornCodeRandomValue(l_i64Value1))
		//	return true;
		if (l_i64Value1 == l_i64Value2)
			return true;
		return false;
	}
	bool	CompareReportCode(const char*e_strReportCode, const char*e_strPlayerInputReportCodeResult)
	{
		if(!strcmp(g_strFishGameParameterizeVersion,"1.3"))
			return CompareReportCode_V_1_3(e_strReportCode,e_strPlayerInputReportCodeResult);
		else
		if(!strcmp(g_strFishGameParameterizeVersion,"1.4"))
			return CompareReportCode_V_1_4(e_strReportCode,e_strPlayerInputReportCodeResult);
		return false;
	}
	#define	DO_CLEAR_REPORT_DATA_INDEX	REPORT_CODE_LENGTH
	#define	DO_PARAMETER_INDEX			DO_CLEAR_REPORT_DATA_INDEX+1
	int		GetReportCodeCheckSum(char*e_strReportCode,int e_iDataLength)
	{
		int l_iSum = 0;
		for (int i = 0; i < e_iDataLength; i++)
		{
			l_iSum += e_strReportCode[i];
		}
		l_iSum %= 10;
		l_iSum += '0';
		return l_iSum;
	}
	//
	int	CombineReportCodeWithParameterSetting(char*e_strReportCode, char*e_strReportCodeResult,sFiGameReporterParameterManager*e_pFiGameReporterParameterManager, bool e_bAssignParameter, bool e_bClearReportData)
	{
		int l_iDataLength = 0;
		memcpy(e_strReportCodeResult, e_strReportCode, REPORT_CODE_LENGTH);
		l_iDataLength += REPORT_CODE_LENGTH;
		const int l_ciParameterOccupyBufferCount = 2;
		const int l_ciCheckSumOccupyBufferCount = 1;
		int l_iParameterCount = e_pFiGameReporterParameterManager->GetDataPointer(&e_strReportCodeResult[DO_CLEAR_REPORT_DATA_INDEX + 2]);
		const char l_cDoParameter = e_bAssignParameter?'1':'0';
		const char l_cClearReportData = e_bClearReportData ? '1' : '0';
		e_strReportCodeResult[DO_PARAMETER_INDEX] = l_cDoParameter;//for clear report data
		e_strReportCodeResult[DO_CLEAR_REPORT_DATA_INDEX] = l_cClearReportData;//for do parameter
		if (!e_bAssignParameter)
		{
			int l_iStartToFilledIndex = DO_CLEAR_REPORT_DATA_INDEX + l_ciParameterOccupyBufferCount;
			int l_iEndToFilledIndex = l_iStartToFilledIndex + l_iParameterCount;
			for (int i = l_iStartToFilledIndex; i < l_iEndToFilledIndex; i++)
			{
				e_strReportCodeResult[i] = rand() % 10 + '0';
			}
		}
		int l_iCodeLength = REPORT_CODE_LENGTH + l_iParameterCount + l_ciParameterOccupyBufferCount;
		int l_iSum = GetReportCodeCheckSum(e_strReportCodeResult, l_iCodeLength);
		e_strReportCodeResult[l_iCodeLength] = l_iSum;
		e_strReportCodeResult[l_iCodeLength+1] = 0;
		return l_iCodeLength+ l_ciCheckSumOccupyBufferCount;
	}

	int		CombineReportCodeWithParameterSetting(char*e_strReportCode, char*e_strReportCodeResult, std::wstring e_strParameterString, bool e_bAssignParameter, bool e_bClearReportData)
	{
		int l_iDataLength = 0;
		memcpy(e_strReportCodeResult, e_strReportCode, REPORT_CODE_LENGTH);
		l_iDataLength += REPORT_CODE_LENGTH;
		const int l_ciParameterOccupyBufferCount = 2;
		const int l_ciCheckSumOccupyBufferCount = 1;
		std::string l_strParameterToCharString = ValueToString(e_strParameterString);
		int	l_iParameterCount = sFiGameReporterParameterManager::GetDataPointerBySTring(&e_strReportCodeResult[DO_CLEAR_REPORT_DATA_INDEX + 2], l_strParameterToCharString.c_str());
		const char l_cDoParameter = e_bAssignParameter ? '1' : '0';
		const char l_cClearReportData = e_bClearReportData ? '1' : '0';
		e_strReportCodeResult[DO_PARAMETER_INDEX] = l_cDoParameter;//for clear report data
		e_strReportCodeResult[DO_CLEAR_REPORT_DATA_INDEX] = l_cClearReportData;//for do parameter
		if (!e_bAssignParameter)
		{
			int l_iStartToFilledIndex = DO_CLEAR_REPORT_DATA_INDEX + l_ciParameterOccupyBufferCount;
			int l_iEndToFilledIndex = l_iStartToFilledIndex + l_iParameterCount;
			for (int i = l_iStartToFilledIndex; i < l_iEndToFilledIndex; i++)
			{
				e_strReportCodeResult[i] = rand() % 10 + '0';
			}
		}
		int l_iCodeLength = REPORT_CODE_LENGTH + l_iParameterCount + l_ciParameterOccupyBufferCount;
		int l_iSum = GetReportCodeCheckSum(e_strReportCodeResult, l_iCodeLength);
		e_strReportCodeResult[l_iCodeLength] = l_iSum;
		e_strReportCodeResult[l_iCodeLength + 1] = 0;
		return l_iCodeLength + l_ciCheckSumOccupyBufferCount;
	}

	bool	CompareReportCodeWithParameter(char*e_strReportCode, char*e_strPlayerInputReportCodeResult)
	{
		if (CompareReportCode(e_strReportCode,e_strPlayerInputReportCodeResult))
		{
			int l_iDataLength = (int)strlen(e_strPlayerInputReportCodeResult)-1;
			int	l_iCheckSum = GetReportCodeCheckSum(e_strPlayerInputReportCodeResult, l_iDataLength);
			if (e_strPlayerInputReportCodeResult[l_iDataLength] == l_iCheckSum)
			{
				return true;
			}
		}
		return false;
	}

    bool DecodeParameter(char* e_strPlayerInputReportCodeResult, const char* lpFileName, WstrVector& rReturWstrVector)
    {
        rReturWstrVector.clear();

        if (!e_strPlayerInputReportCodeResult)
            return false;
		int l_iCodeLength = (int)strlen(e_strPlayerInputReportCodeResult);
        char lchValueCount[4];
        memset(lchValueCount, '\0', sizeof(lchValueCount));

        //lchValueCount[0] = e_strPlayerInputReportCodeResult[DO_CLEAR_REPORT_DATA_INDEX];
        lchValueCount[0] = e_strPlayerInputReportCodeResult[DO_CLEAR_REPORT_DATA_INDEX + 1];

        const int iParameterReportCodeZeroIndex = DO_CLEAR_REPORT_DATA_INDEX + 2;
        const int iMaxCount = l_iCodeLength - iParameterReportCodeZeroIndex;
        
        int lnValueCount = atoi(lchValueCount);

        if (lnValueCount == 0)
            return true;

        //if (iMaxCount < lnValueCount)
        //    lnValueCount = iMaxCount;
        lnValueCount = 16;
        
        const int iCharZero = 48;
        sFiGameReporterParameterManager  lFiGameReporterParameterManager;
        sFiGameReporterParameterManager* plFiGameReporterParameterManager = &lFiGameReporterParameterManager;
        wstring lwsGetString;

        PARSEWITHMYPARSE_FAILED_MESSAGE_BOX(plFiGameReporterParameterManager, lpFileName);
 
        for (int i = 0; i < lnValueCount; i++)
        {
            lwsGetString = plFiGameReporterParameterManager->GetStringByDataAndObjectIndex(e_strPlayerInputReportCodeResult[iParameterReportCodeZeroIndex + i] - iCharZero, i);
            rReturWstrVector.push_back(lwsGetString);
        }

        return true;
    }
	int sTwLeadStreamProductData::GetTwLeadStreamProductDataNumber()
	{
		//1.0-1.2
		int l_iValue = this->iMachineID + (this->iProductTypeNumber);
		//version after 1.3 add a new magic number
		//int l_iValue = (this->iMachineID*g_iReportCodeLazyMagicNumber) + (this->iProductTypeNumber*g_iReportCodeLazyMagicNumber);
		l_iValue += g_iReportCodeLazyMagicNumber;
		return l_iValue;
	}
}