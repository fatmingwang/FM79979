#pragma once

#include "FishGameParameterObject.h"
//http://www.cplusplus.com/forum/general/124799/

#define	REPORT_CODE_LENGTH 15

//#define	REPORT_CODE_WITH_PARAMETER_LENGTH 30

typedef std::vector<std::wstring> WstrVector;

using namespace FATMING_CORE;


namespace FISG_GAME_PARAMETERIZE
{
	static const char*	g_strFishGameParameterizeVersion = "1.3";
	//1.0
	//1.1	buffer 15,16, change to clear report data flag(15),use parameter flag setting(16)
	//		ExchangeIn/Out is money not score.
	//1.2	Normal Pumping Water Level Field adjustment
	//1.3   change GenerateReportCodeMagicNumber(iProductTypeNumber+iMachineID change to GetTwLeadStreamProductDataNumber)

	struct sFiGameReporterParameterManager;
	//
	bool	BigEndianMemcpy(char*e_pSrcData, char*e_pCopyToData, int e_iStartCopy, int e_iEndCopy);
	//
	struct sTwLeadStreamProductData
	{
		int		iProductTypeNumber = 0;
		int		iMachineID = 0;
		//uint64	i64UniqueID = 0;
		int		GetTwLeadStreamProductDataNumber();
	};
	//============================================================================================
	//hex coding report
	//for 30 character to compress e_i64ExchangeIn,e_i64ExchangeOut,e_i64ShootBulletAmount
	//restriction each int64 for 8 byte 0xffffffff
	//return code length is 30,30-(3*4*2)-(3*2) = 0
	//4,4,4 for exchange in,out, bullet amount
	//2 byte for how many times has been report(if over 65536 get modulate)
	//1 byte(4 bit(16) for choice what xor code),4 bit for any input value is over 0xfffffffff
	void	GenerateFirstThreeCode(char*e_pOutData,uint64 &e_i64ExchangeIn,uint64 &e_i64ExchangeOut,uint64 &e_i64ShootBulletAmount,int e_iReportCount);
	bool	GetTimeUpResultData(char*l_pOutData,sTwLeadStreamProductData e_sTwLeadStreamProductData,
								uint64 e_i64ExchangeIn,
								uint64 e_i64ExchangeOut,
								uint64 e_i64ShootBulletAmount,
								int e_iReportCount,char*e_pOriginalDataWithoutEncryption = nullptr);
	bool	DecryptionTimeUpResultData(sTwLeadStreamProductData e_sTwLeadStreamProductData, char*e_pEncryptionData, char*e_pDecryptionData);
	bool	IsTimeUpResultDataMatch(sTwLeadStreamProductData e_sTwLeadStreamProductData,char*e_pDecrytionData,
		uint64 e_i64ExchangeIn,
		uint64 e_i64ExchangeOut,
		uint64 e_i64ShootBulletAmount);
	//============================================================================================
	//15 characters report,sTwLeadStreamProductData setting
	//e_strOutData 15(MACHINE_INITIALIZE_CODE_LENGTH) characters,
	//new machine setup
	//1. get time code
	bool	MachineSeetingGenerateTimeCode(char*e_pOutTimeCodeData);
	//2.give sTwLeadStreamProductData and player input and time code to compare
	bool	MachineSeetingGenerateTimeCodeByTwLeadStreamMachineID(char*e_pTimeCodeData, char*e_pOutResultData, sTwLeadStreamProductData e_sTwLeadStreamProductData);
	//3.compare data
	bool	CompareTwLeadStreamMachineTimeCode(char*e_pPlayerInputData,char*e_pTimeCodeData,sTwLeadStreamProductData e_sTwLeadStreamProductData);
	//============================================================================================
	//time's up report
	//first 3 code is random value and the magic number length
	//all the data is current round not total.
	bool	GenerateReportCode(char*e_strReportCodeOutData,uint64 e_i64ExchangeIn,uint64 e_i64ExchangeOut,uint64 e_iBulletCount,int e_iReportCount,sTwLeadStreamProductData e_sTwLeadStreamProductData);
	int64	ReportCodeToNumber(const char*e_strReportCodeOutData);
	//for report app or machine
	bool	GenerateReportCodeResult(char*e_strReportCode,char*e_strReportCodeResult, sTwLeadStreamProductData e_sTwLeadStreamProductData);
	//for game.
	bool	CompareReportCode(const char*e_strReportCode,const char*e_strPlayerInputReportCodeResult);
	//for editor to combine extra setting,return data length
	int		CombineReportCodeWithParameterSetting(char*e_strReportCode, char*e_strReportCodeResult,sFiGameReporterParameterManager*e_pFiGameReporterParameterManager,bool e_bAssignParameter, bool e_bClearReportData);
	int		CombineReportCodeWithParameterSetting(char*e_strReportCode, char*e_strReportCodeResult,std::wstring e_strParameterString, bool e_bAssignParameter, bool e_bClearReportData);
	bool	CompareReportCodeWithParameter(char*e_strReportCode, char*e_strPlayerInputReportCodeResult);

    bool	DecodeParameter(char*e_strPlayerInputReportCodeResult, const char* lpFileName, WstrVector& rReturWstrVector);


	bool	GenerateReportCode_V_1_3(char*e_strReportCodeOutData, uint64 e_i64ExchangeIn, uint64 e_i64ExchangeOut, uint64 e_iBulletCount, int e_iReportCount, sTwLeadStreamProductData e_sTwLeadStreamProductData);
	bool	CompareReportCode_V_1_3(const char*e_strReportCode, const char*e_strPlayerInputReportCodeResult);

	bool	GenerateReportCode_V_1_4(char*e_strReportCodeOutData, uint64 e_i64ExchangeIn, uint64 e_i64ExchangeOut, uint64 e_iBulletCount, int e_iReportCount, sTwLeadStreamProductData e_sTwLeadStreamProductData);
	bool	CompareReportCode_V_1_4(const char*e_strReportCode, const char*e_strPlayerInputReportCodeResult);
}

//for first time machine setup
//char l_OutTimeCodeData[MACHINE_INITIALIZE_CODE_LENGTH];
//char l_ForPlayerInputData[MACHINE_INITIALIZE_CODE_LENGTH];
//FISG_GAME_PARAMETERIZE::MachineSeetingGenerateTimeCode(l_OutTimeCodeData);
//FISG_GAME_PARAMETERIZE::MachineSeetingGenerateTimeCodeByTwLeadStreamMachineID(l_OutTimeCodeData, l_ForPlayerInputData, l_TwLeadStreamProductData);
//FISG_GAME_PARAMETERIZE::CompareTwLeadStreamMachineTimeCode(l_ForPlayerInputData, l_OutTimeCodeData, l_TwLeadStreamProductData);


//uint64 l_i64ExchangeIn = 12300;
//uint64 l_i64ExchangeOut = 12500;
//int l_iReportCount = 1;
//
//char l_cReportCodeBuffer[15];
//char l_strReportCodeResult[15];
//for (int i = 0; i < 90; i++)
//{
//	l_i64ExchangeIn = rand();
//	l_i64ExchangeOut = rand();
//	l_iReportCount = rand();
//	GenerateReportCode(l_cReportCodeBuffer, l_i64ExchangeIn, l_i64ExchangeOut, l_iReportCount, l_TwLeadStreamProductData);
//	int64	l_i64Result = FISG_GAME_PARAMETERIZE::ReportCodeToNumber(l_cReportCodeBuffer);
//	GenerateReportCodeResult(l_cReportCodeBuffer, l_strReportCodeResult, l_TwLeadStreamProductData);
//	CompareReportCode(l_cReportCodeBuffer, l_strReportCodeResult, l_TwLeadStreamProductData);
//}
//
//GenerateReportCode(l_cReportCodeBuffer, l_i64ExchangeIn, l_i64ExchangeOut, l_iReportCount, l_TwLeadStreamProductData);
//int64	l_i64Result = FISG_GAME_PARAMETERIZE::ReportCodeToNumber(l_cReportCodeBuffer);
//GenerateReportCodeResult(l_cReportCodeBuffer, l_strReportCodeResult, l_TwLeadStreamProductData);
//CompareReportCode(l_cReportCodeBuffer, l_strReportCodeResult, l_TwLeadStreamProductData);