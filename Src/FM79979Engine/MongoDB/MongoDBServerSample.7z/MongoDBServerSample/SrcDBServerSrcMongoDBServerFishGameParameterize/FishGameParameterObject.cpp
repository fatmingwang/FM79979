#ifdef WIN32
#include "stdafx.h"
#else
#include "../../Core/AllCoreInclude.h"
#endif
#include "FishGameParameterObject.h"
namespace FISG_GAME_PARAMETERIZE
{
	sFiGameReporterParameter::sFiGameReporterParameter(TiXmlElement * e_pTiXmlElement)
	{
		//m_iCopyToBufferStartIndex = -1;
		m_pListValuChangerBase = nullptr;
		int l_iDefaultSelectedIndex = 0;
		int l_iCopyToBufferStartIndex = 0;
		PARSE_ELEMENT_START(e_pTiXmlElement)
			COMPARE_NAME("Name")
			{
				this->SetName(l_strValue);
			}
		PARSE_NAME_VALUE_END
		m_pListValuChangerBase = cListValuChangerBase::GetListValuChangerBaseByElement(e_pTiXmlElement->FirstChildElement());
		
	}
	sFiGameReporterParameter::~sFiGameReporterParameter()
	{
		SAFE_DELETE(m_pListValuChangerBase);
	}
	bool sFiGameReporterParameter::CopyTo(char * e_pData)
	{
		//if (m_pListValuChangerBase)
		//{
		//	if (m_pListValuChangerBase->GetSelectedIndex() != -1)
		//	{
		//		auto l_strData = m_pListValuChangerBase->ConvertSelectedDataToString();
		//		if (l_strData.length() > 0)
		//		{
		//			eDataType l_eDataType = m_pListValuChangerBase->GetDataType();
		//			int	l_iSize = g_iDataTypeSize[l_eDataType];
		//			//if (l_iSize != 0 && this->m_iCopyToBufferStartIndex != -1)
		//			{
		//				memcpy(&e_pData[m_iCopyToBufferStartIndex], m_pListValuChangerBase->GetSelectedDataPonter(), l_iSize);
		//				return true;
		//			}
		//		}
		//	}
		//}
		return false;
	}
	std::vector<wstring> sFiGameReporterParameter::GetDataListToStringVectorForShow()
	{
		std::vector<wstring> l_strVector;
		if (m_pListValuChangerBase)
		{
			m_pListValuChangerBase->SetSelectedIndex(0);
			int l_iIndex = m_pListValuChangerBase->GetSelectedIndex();
			if (l_iIndex == 0)
			{
				int l_iNewIndex = -1;
				while (l_iIndex != l_iNewIndex)
				{
					l_strVector.push_back(m_pListValuChangerBase->ConvertSelectedDataToString());
					m_pListValuChangerBase->Next();
					l_iNewIndex = m_pListValuChangerBase->GetSelectedIndex();
				}
			}
		}
		return l_strVector;
	}

	sFiGameReporterParameterManager::sFiGameReporterParameterManager()
	{

	}

	sFiGameReporterParameterManager::~sFiGameReporterParameterManager()
	{
	}

	//<sFiGameReporterParameter>
	//	<FiGameReporterParameter Name="ProbabilityMode" DefaultSelectedIndex="0" CopyToBufferStartIndex="0">
	//		<cListValueChanger DataType="int" Data="0,1,2,3,4,5" />
	//	</FiGameReporterParameter>
	//</sFiGameReporterParameter>
	bool sFiGameReporterParameterManager::MyParse(TiXmlElement*e_pRoot)
	{
		FOR_ALL_FIRST_CHILD_AND_ITS_CIBLING_START(e_pRoot)
			auto l_strName = e_pRoot->Value();
			COMPARE_NAME("FiGameReporterParameter")
			{
				ProcessFiGameReporterParameter(e_pRoot);
			}
		FOR_ALL_FIRST_CHILD_AND_ITS_CIBLING_END(e_pRoot)
		return true;
	}

	int sFiGameReporterParameterManager::GetDataPointer(char*e_pOutData)
	{
		int l_iIndex = 0;
		int l_iCount = this->Count();
		int l_iParameterCount = l_iCount;
		for (int i = 0; i < l_iCount; i++)
		{
			auto l_pObject = GetObject(i);
			cListValueChanger<std::wstring>*l_pListValueChanger = (cListValueChanger<std::wstring>*)l_pObject->m_pListValuChangerBase;
			int l_iSelectedIndex = l_pObject->m_pListValuChangerBase->GetSelectedIndex();
			if (l_pListValueChanger->GetDataList()->size() > 9)
			{
				e_pOutData[l_iIndex] = l_iSelectedIndex/10 + '0';
				++l_iIndex;
				e_pOutData[l_iIndex] = l_iSelectedIndex % 10 + '0';
				++l_iParameterCount;
			}
			else
			{
				e_pOutData[l_iIndex] = l_iSelectedIndex + '0';
			}
			++l_iIndex;
			//memcpy(&e_pOutData[l_pObject->m_iCopyToBufferStartIndex], l_pObject->m_pListValuChangerBase->GetSelectedDataPonter(), l_iBufferSize);
			//int l_iBufferSize = g_iDataTypeSize[l_pObject->m_pListValuChangerBase->GetDataType()];
			//e_iDataLength += l_iBufferSize;
		}
		return l_iParameterCount;
	}

	int		sFiGameReporterParameterManager::GetDataPointerBySTring(char*e_pOutData, const char*e_strParameterString)
	{
		int l_iIndex = 0;
		char l_strTemp[60];
		sprintf(l_strTemp, "%s", e_strParameterString);
		std::wstring l_strWcharConvert = ValueToStringW(e_strParameterString);
		std::vector<std::string> l_strVector = GetStringListByCommaDivide(l_strWcharConvert.c_str());
		std::vector<int> l_ParameterVector = GetIntegerListByCommaDivide(l_strTemp, 20);
		int l_iCount = (int)l_ParameterVector.size();
		int l_iParameterCount = l_iCount;
		for (int i = 0; i < l_iCount; i++)
		{
			int l_iSelectedIndex = l_ParameterVector[i];
			if (l_strVector[i].length() >= 2)
			{
				e_pOutData[l_iIndex] = l_iSelectedIndex / 10 + '0';
				++l_iIndex;
				e_pOutData[l_iIndex] = l_iSelectedIndex % 10 + '0';
				++l_iParameterCount;
			}
			else
			{
				e_pOutData[l_iIndex] = l_iSelectedIndex + '0';
			}
			++l_iIndex;
			//memcpy(&e_pOutData[l_pObject->m_iCopyToBufferStartIndex], l_pObject->m_pListValuChangerBase->GetSelectedDataPonter(), l_iBufferSize);
			//int l_iBufferSize = g_iDataTypeSize[l_pObject->m_pListValuChangerBase->GetDataType()];
			//e_iDataLength += l_iBufferSize;
		}
		return l_iParameterCount;
	}

	std::wstring sFiGameReporterParameterManager::GetStringByDataAndObjectIndex(int e_iCode,int e_iObjectIndex)
	{
		std::wstring l_strResult;
		auto l_pObject = this->GetObject(e_iObjectIndex);
		if (l_pObject->m_pListValuChangerBase)
		{
			
			eDataType l_eDataType = l_pObject->m_pListValuChangerBase->GetDataType();
			if (g_iDataTypeSize[l_eDataType] > sizeof(int))
			{
				assert(0&&"data type cannt bigger than int");
			}
			else
			{
				l_pObject->m_pListValuChangerBase->SetSelectedIndex(e_iCode);
				//int l_iValue = *(int*)l_pObject->m_pListValuChangerBase->GetSelectedDataPonter();
				l_strResult = l_pObject->m_pListValuChangerBase->ConvertSelectedDataToString();
			}
		}
		return l_strResult;
	}

	bool	sFiGameReporterParameterManager::ProcessFiGameReporterParameter(TiXmlElement*e_pRoot)
	{
		sFiGameReporterParameter*l_pFiGameReporterParameter = new sFiGameReporterParameter(e_pRoot);
		this->AddObjectNeglectExist(l_pFiGameReporterParameter);
		return true;
	}
}