#pragma once

#include "../../Core/GameplayUT/ListValueChanger.h"
//http://www.cplusplus.com/forum/general/124799/
namespace FISG_GAME_PARAMETERIZE
{
	//<FiGameReporterParameter Name="ProbabilityMode" DefaultSelectedIndex="0" CopyToBufferStartIndex="0">
	//	<cListValueChanger DataType="int" Data="0,1,2,3,4,5" />
	//</FiGameReporterParameter>
	struct sFiGameReporterParameter :public NamedTypedObject
	{
		sFiGameReporterParameter(TiXmlElement*e_pTiXmlElement);
		virtual ~sFiGameReporterParameter();
		FATMING_CORE::cListValuChangerBase*m_pListValuChangerBase;
		//int		m_iCopyToBufferStartIndex;
		bool	CopyTo(char*e_pData);
		std::vector<wstring>		GetDataListToStringVectorForShow();
	};

	struct sFiGameReporterParameterManager :public cNamedTypedObjectVector<sFiGameReporterParameter>, public cNodeISAX
	{
	public:
		bool	ProcessFiGameReporterParameter(TiXmlElement*e_pRoot);
		//
		sFiGameReporterParameterManager();
		virtual ~sFiGameReporterParameterManager();
		virtual	bool		MyParse(TiXmlElement*e_pRoot);
		//return data length
		int					GetDataPointer(char*e_pOutData);
		static int			GetDataPointerBySTring(char*e_pOutData,const char*e_strParameterString);
		std::wstring		GetStringByDataAndObjectIndex(int e_iCode,int e_iObjectIndex);
	};

}