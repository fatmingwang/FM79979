#pragma once

#include "FishDBStructer.h"

#define EVENT_STRUCTURE_SIZE(TYPE) virtual int Size()override{return sizeof(TYPE);}
//==================================
//user collection must fetch while server start to run.
//
//I am lazy here should replace by some filter,something like below.
//stdx::optional<bsoncxx::document::value> find_one(bsoncxx::document::view_or_value filter, const options::find& options = options::find());
//
enum eDB_CURD_Type
{
	eDB_CURD_CREATE_USER = 0,
	eDB_CURD_UPDATE_USER,
	eDB_CURD_DELETE_USER,
	eDB_CURD_UPDATE_USER_MACHINE,
	eDB_CURD_ADD_REPORT_DATA,
	eDB_CURD_MAX,
};
//CURD	//create//update//read//delete
struct sCURD_DataBase
{
	struct _TCPsocket*	pClientSocket = nullptr;
	eDB_CURD_Type		DBcurdType = eDB_CURD_MAX;
	std::string			strID;//for check with coket to avoid someone pretend another one.
	//std::string			strCollectionName;
	virtual int			Size() = 0;
};

struct sCURD_CreateUser :public sCURD_DataBase
{
	std::string		strCreateID;
	std::string		strPWD;
	std::string		strDescription;
	EVENT_STRUCTURE_SIZE(sCURD_CreateUser);
};

struct sCURD_UpdateUser :public sCURD_DataBase
{
	std::string strTargetID;
	std::string strPWD;
	std::string strNewPWD;
	std::string strDescription;
	EVENT_STRUCTURE_SIZE(sCURD_UpdateUser);
};

struct sCURD_DeleteUser :public sCURD_DataBase
{
	std::string strPWD;
	std::string strDeleteID;
	EVENT_STRUCTURE_SIZE(sCURD_DeleteUser);
};

struct sCURD_UpdateUser_Machine :public sCURD_DataBase
{
	std::string strTargetID;
	bool		bAdd;//true for add false for delete
	int			iMachineID;
	EVENT_STRUCTURE_SIZE(sCURD_UpdateUser_Machine);
};

//eDB_CURD_ADD_REPORT_DATA
struct sCURD_AddReportData :public sCURD_DataBase
{
	sReportInfoWithReportCodes	ReportInfo;
	char						strParameterCode[50];
	std::string					strCodeReportVersion;
	EVENT_STRUCTURE_SIZE(sCURD_AddReportData);
};