#include "stdafx.h"
#include "User.h"
#include "EventMessage.h"

TYPDE_DEFINE_MARCO(cUserVector);


cUserVector::cUserVector()
{

}

cUserVector::~cUserVector()
{
	Destroy();
}

void	cUserVector::Destroy()
{
	m_TCPSocketAndConnectedUserMap.clear();
	cNamedTypedObjectVector<cUser>::Destroy();
}

cUser*	cUserVector::AddActivedConnectedUser(_TCPsocket*e_pSocket,const char*e_strID)
{
	auto l_pUser = GetActivedConnectedUser(e_pSocket);
	if (l_pUser)
	{
		FMLog::LogWithFlag(UT::ComposeMsgByFormat("this user:%s exists!?same ID but different IP", e_strID).c_str(), LOG_ID_USER,true);
		return l_pUser;
	}
	l_pUser = this->GetObject(e_strID);
	if (l_pUser)
	{
		l_pUser->SetLogin(true, e_pSocket);
		m_TCPSocketAndConnectedUserMap.insert(std::make_pair(e_pSocket, l_pUser));
	}
	return l_pUser;
}
cUser*	cUserVector::GetActivedConnectedUser(_TCPsocket*e_pSocket)
{
	auto l_Iterator = m_TCPSocketAndConnectedUserMap.find(e_pSocket);
	if (l_Iterator != m_TCPSocketAndConnectedUserMap.end())
	{
		return l_Iterator->second;
	}
	return nullptr;
}

bool	cUserVector::RemoveActivedConnectedUser(_TCPsocket*e_pSocket)
{
	auto l_Iterator = m_TCPSocketAndConnectedUserMap.find(e_pSocket);
	if (l_Iterator != m_TCPSocketAndConnectedUserMap.end())
	{
		l_Iterator->second->SetLogin(false,nullptr);
		m_TCPSocketAndConnectedUserMap.erase(l_Iterator);
		return true;
	}
	return false;
}

bool cUserVector::UserAddNewMachineToDB(int e_iUserID, int e_iMachineID)
{
	cUser*l_pConnectedUser = this->GetObject(e_iUserID);
	return false;
}

bool cUserVector::AddHostoryDataByMachineNumberToDB(int e_iUserID,int e_iMachineID, sReportInfoWithReportCodes e_ReportData)
{
	cUser*l_pConnectedUser = this->GetObject(e_iUserID);

	return false;
}

bool cUserVector::AddUserToDB(std::wstring e_strUserName, eUserAuthority e_eUserAuthority)
{
	return false;
}

bool cUserVector::AdminAuthorityCheck(cUser*e_pUser, std::string&e_strErrorMessage)
{
	if (!e_pUser || e_pUser->GetUserData().m_eUserAuthority != eUserAuthority::eUA_ADMIN)
	{
		e_strErrorMessage = UT::ComposeMsgByFormat("User authority is not enough!:authority:%d", (int)e_pUser->GetUserData().m_eUserAuthority);
		return false;
	}
	return true;
}

bool cUserVector::AdminAuthorityAndTargetUserCheck(cUserVector*e_pUserVector, cUser * e_pUser, const char * e_strTargetID, std::string & e_strErrorMessage)
{
	if (!e_pUser || e_pUser->GetUserData().m_eUserAuthority != eUserAuthority::eUA_ADMIN)
	{
		e_strErrorMessage = UT::ComposeMsgByFormat("User authority is not enough!:authority:%d", (int)e_pUser->GetUserData().m_eUserAuthority);
		return false;
	}
	if (!e_pUserVector->GetObject(e_strTargetID))
	{
		e_strErrorMessage = UT::ComposeMsgByFormat("target id is not exists:%d", (int)e_pUser->GetUserData().m_eUserAuthority);
	}
	return true;
}

//cConnectedUser * cUserVector::GetObjectByID(int e_iID)
//{
//	return cNamedTypedObjectVector<cConnectedUser>::GetObject(ValueToStringW(e_iID).c_str());
//}