#include "stdafx.h"
#include "MongoDB.h"
#include "User.h"
#include "EventMessage.h"
#include "MongoDBCommonFunction.h"
#include "DBFieldName.h"

#include <locale>
#include <codecvt>
#include <string>

cMongoDB::cMongoDB()
{
	ConnectToDBServer("10.168.1.143:27017","fatming","1234");
	REG_EVENT(eEM_MONGODB_INITIALIZE_START,&cMongoDB::RefreshUserCollectionEvent);
	m_bInitMongoDB = false;
	cPP11MutexHolder l_cPP11MutexHolder(m_Mutex);
	f_ThreadWorkingFunction l_f_ThreadWorkingFunction = std::bind(&cMongoDB::ThreadUpdate, this, std::placeholders::_1);
	ThreadDetach(l_f_ThreadWorkingFunction);
}

cMongoDB::~cMongoDB()
{
}

bool cMongoDB::RefreshUserCollectionEvent(void*e_pData)
{
	m_bRefreshDataFromDB = true;
	return false;
}

void cMongoDB::ConnectToDBServer(const char * e_strIPAndPort, const char * e_strUserName, const char*e_strPWD)
{
	m_strIPAndPort = e_strIPAndPort;
	m_strUserName = e_strUserName;
	m_strPWD = e_strPWD;
}

void cMongoDB::SetRefreshDataFromDB(bool e_b)
{
	CloseThreadAndWaitUntilFinish();
}

void	cMongoDB::Refresh()
{
	MongoDBInit();
	UserCollectionInit();
}


//http://mongocxx.org/mongocxx-v3/tutorial/
//https://groups.google.com/forum/#!topic/mongodb-user/M7vM0h7rKlE
//bsoncxx::document::element e = doc["timestamp"];  // element is a non-owning view of a single key/value pair

//// Check that the element exists and is of the right type
//if (e && e.type() = bsoncxx::type::k_int64) 
//{
//	// extract value as bsoncxx::types::b_int64, which converts to int64_t
//	int64_t timestamp = e.get_int64();
//}

//https://stackoverflow.com/questions/2573834/c-convert-string-or-char-to-wstring-or-wchar-t
//std::wstring_convert<std::codecvt_utf8_utf16<wchar_t>> converter;
////std::string narrow = converter.to_bytes(wide_utf16_source_string);
////std::wstring wide = converter.from_bytes(narrow_utf8_source_string);
//std::wstring wide = converter.from_bytes(l_strName.value.to_string());
//
////https://stackoverflow.com/questions/35920013/new-c-mongo-driver-how-to-see-type-and-how-to-get-string-value/35920720

void	cMongoDB::TestCode()
{
#if defined(DEBUG)
	if (1)
	{
		FMLog::LogWithFlag("cMongoDB::TestCode", LOG_ID_MONGO_DB, true);
		int			l_iTestMachineID = 99;
		const char*l_strID = "a123";
		const char*l_strCreateNewID = "z123";
		const char*l_strPWD = "456";
		const char*l_strNewPWD = "799";
		std::wstring l_strWDescription = L"�Թخ@";
		std::string l_strDescription = STDWStringToString(l_strWDescription);
		auto l_pUserVector = cUserVector::GetInstance();
		auto l_pUser = l_pUserVector->GetObject(l_strID);
		//sUserDataInUserCollection l_sUserDataInUserCollection;
		//l_sUserDataInUserCollection.strID = l_strID;
		//l_sUserDataInUserCollection.strPWD = l_strPWD;
		//l_sUserDataInUserCollection.strDescription = l_strDescription;
		//cConnectedUser l_cConnectedUser(l_sUserDataInUserCollection);
		sCURD_CreateUser l_sCURD_CreateUser; l_sCURD_CreateUser.strCreateID = l_strCreateNewID;
		sCURD_UpdateUser l_sCURD_UpdateUser; l_sCURD_UpdateUser.strNewPWD = l_strNewPWD;
		sCURD_DeleteUser l_sCURD_DeleteUser; l_sCURD_DeleteUser.strDeleteID = l_strCreateNewID; l_sCURD_DeleteUser.strPWD = l_strNewPWD;
		sCURD_UpdateUser_Machine l_CURD_UpdateUser_Machine; l_CURD_UpdateUser_Machine.iMachineID = l_iTestMachineID;
		sCURD_AddReportData l_CURD_Data; l_CURD_Data.ReportInfo.iMachineID = 88; l_CURD_Data.strCodeReportVersion = "1.3";
		l_CURD_Data.strID = l_CURD_UpdateUser_Machine.strTargetID = l_CURD_UpdateUser_Machine.strID = l_sCURD_DeleteUser.strID = l_sCURD_UpdateUser.strID = l_sCURD_CreateUser.strID = l_strID;
		l_sCURD_UpdateUser.strDescription = l_sCURD_CreateUser.strDescription = l_strDescription;
		l_sCURD_UpdateUser.strPWD = l_sCURD_CreateUser.strPWD = l_strPWD;
		//tested April/12/2019
		//Process_eDB_CURD_CREATE_USER(&l_sCURD_CreateUser, &l_cConnectedUser);
		//Process_eDB_CURD_UPDATE_USER(&l_sCURD_UpdateUser, &l_cConnectedUser);
		//Process_eDB_CURD_DELETE_USER(&l_sCURD_DeleteUser, &l_cConnectedUser);
		//tested April/16/2019
		//Process_eDB_CURD_UPDATE_USER_MACHINE(&l_CURD_UpdateUser_Machine, l_pUser);
		//l_CURD_UpdateUser_Machine.bAdd = false;
		//l_CURD_UpdateUser_Machine.iMachineID = 1002;
		//Process_eDB_CURD_UPDATE_USER_MACHINE(&l_CURD_UpdateUser_Machine, l_pUser);
		//
		//
		Process_eDB_CURD_ADD_REPORT_DATA(&l_CURD_Data, l_pUser);
	}
#endif
}

void	cMongoDB::MongoDBInit()
{
	if (m_bInitMongoDB)
		return;
	FMLog::LogWithFlag("MongoDBInit()",LOG_ID_MONGO_DB, true);
	m_bInitMongoDB = true;
	//mongocxx::uri uri("mongodb://10.168.1.143:27017");
	std::string l_strQueryAddress = "mongodb://";
	l_strQueryAddress += m_strUserName;
	l_strQueryAddress += ":";
	l_strQueryAddress += m_strPWD;
	l_strQueryAddress += "@";
	l_strQueryAddress += m_strIPAndPort;
	l_strQueryAddress += "/?authSource=admin";
	//mongocxx::uri uri("mongodb://fatming:1234@10.168.1.143:27017/?authSource=admin");
	FMLog::LogWithFlag(UT::ComposeMsgByFormat("cMongoDB::MongoDBInit:%s", l_strQueryAddress.c_str()), LOG_ID_MONGO_DB, true);
	mongocxx::uri uri(l_strQueryAddress.c_str());
	mongocxx::client client(uri);
	m_FishDatabase = client["Fish"];
	m_UserDataCollection = m_FishDatabase["UserData"];
	try
	{
		FMLog::LogWithFlag("cMongoDB::MongoDBInit:try to parse sUserDataInUserCollection", LOG_ID_MONGO_DB, true);
		cUserVector*l_pUserVector = cUserVector::GetInstance();
		mongocxx::cursor l_Cursor = m_UserDataCollection.find({});
		for (auto l_View : l_Cursor)
		{
			sUserDataInUserCollection l_UserDataInUserCollection;
			if (UserDataProcess(l_View, l_UserDataInUserCollection))
			{
				if (!l_pUserVector->GetObject(l_UserDataInUserCollection.strID.c_str()))
				{
					cUser*l_pConnectedUser = new cUser(l_UserDataInUserCollection);
					l_pUserVector->AddObject(l_pConnectedUser);
					FMLog::LogWithFlag(UT::ComposeMsgByFormat("Ok fetch user ID:%s:%s", l_UserDataInUserCollection.strID.c_str(),l_UserDataInUserCollection.strID.c_str()), LOG_ID_MONGO_DB, true);
				}
				else
				{
					FMLog::LogWithFlag(UT::ComposeMsgByFormat("Error same user ID:%s:%s", l_UserDataInUserCollection.strID.c_str(), l_UserDataInUserCollection.strID.c_str()), LOG_ID_MONGO_DB, true);
				}
			}
		}
		TestCode();
	}
	catch (std::exception e)
	{
		std::string l_str = "Error Exception FetchUserData failed:";
		l_str += e.what();
		FMLog::LogWithFlag(l_str.c_str(), LOG_ID_MONGO_DB,true);
	}
}

void	cMongoDB::UserCollectionInit()
{
	if (!m_bRefreshDataFromDB)
		return;
	m_bRefreshDataFromDB = false;
	m_UserIDAndCollectionPointerMap.clear();
	//do for m_UserDataCollection;
	cGameApp::EventMessageShot(eEM_MONGODB_INITIALIZE_FINISH, nullptr);
}

mongocxx::collection*	cMongoDB::FetchCollectionByName(const char*e_strName)
{
	mongocxx::collection*l_pCollection = nullptr;
	int l_iValue = GetInt(e_strName);
	if (l_iValue > 0)
	{
		if (m_UserIDAndCollectionPointerMap.find(l_iValue) == m_UserIDAndCollectionPointerMap.end())
		{
			mongocxx::collection l_Collection;
			if (m_FishDatabase.has_collection(e_strName))
			{
				l_Collection = m_FishDatabase[e_strName];
			}
			else
			{
				l_Collection = m_FishDatabase.create_collection(e_strName);
				FMLog::Log(UT::ComposeMsgByFormat("CollectionName:%s created!", e_strName).c_str(), true);
			}
			m_UserIDAndCollectionPointerMap.insert(std::make_pair(l_iValue, l_Collection));
		}
		l_pCollection = &m_UserIDAndCollectionPointerMap[l_iValue];
	}
	if (!l_pCollection)
	{
		FMLog::Log(UT::ComposeMsgByFormat("CollectionName:%s not correct!",e_strName).c_str(),true);
	}
	return l_pCollection;
}

void	cMongoDB::AddQueryData(sCURD_DataBase*e_pCURD_DataBase)
{
	MUTEX_PLACE_HOLDER(m_QueryDataVectorMutex);
	m_QueryDataVector.push_back(e_pCURD_DataBase);
}

void cMongoDB::ThreadUpdate(float e_fElpaseTime)
{
	Refresh();
	{
		MUTEX_PLACE_HOLDER(m_QueryDataVectorMutex);
		while (m_QueryDataVector.size())
		{
			auto l_pQueryData = m_QueryDataVector[0];
			Process_DB_CURD(l_pQueryData);
			m_QueryDataVector.erase(m_QueryDataVector.begin());
			delete l_pQueryData;
		}
	}
}
extern cMongoDB*g_pMongoDB;
void	AddQueryDataIntoDBQueryVector(sCURD_DataBase*e_pCURD_DataBase)
{
	if (g_pMongoDB)
	{
		g_pMongoDB->AddQueryData(e_pCURD_DataBase);
	}
}