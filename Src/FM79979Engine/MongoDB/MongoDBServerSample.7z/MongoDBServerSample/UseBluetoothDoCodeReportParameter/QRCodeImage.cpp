#include "stdafx.h"
#include "QRCodeImage.h"
#include "../../QRCode/QrCode.hpp"
#include "UseBluetoothDoCodeReportParameter.h"
using namespace qrcodegen;
cQRImage::cQRImage(Vector2 e_vImageSize)
{
	m_pFrameBuffer = new cFrameBuffer((int)e_vImageSize.x, (int)e_vImageSize.y);
}

cQRImage::~cQRImage()
{
	SAFE_DELETE(m_pFrameBuffer);
}

void	cQRImage::SetData(sReportInfo* e_pReportInfo)
{
	std::vector<int64> l_i64ValueVector;
	l_i64ValueVector.push_back(e_pReportInfo->iReportCount);
	l_i64ValueVector.push_back(e_pReportInfo->iProductTypeNumber);
	l_i64ValueVector.push_back(e_pReportInfo->iMachineID);
	l_i64ValueVector.push_back(e_pReportInfo->i64ExchangeIn);
	l_i64ValueVector.push_back(e_pReportInfo->i64ExchangeOut);
	l_i64ValueVector.push_back(e_pReportInfo->i64BulletShootCount);
	l_i64ValueVector.push_back(e_pReportInfo->i64BetMoney);
	l_i64ValueVector.push_back(e_pReportInfo->i64WinMoney);
	l_i64ValueVector.push_back(e_pReportInfo->i64BulletTotalShootCount);
	l_i64ValueVector.push_back(e_pReportInfo->i64OVERCount);
	l_i64ValueVector.push_back(e_pReportInfo->i64OVERScore);
	l_i64ValueVector.push_back(e_pReportInfo->i64GameWater);
	SetData(l_i64ValueVector);
}


void cQRImage::SetData(std::vector<int64>&e_i64ValueVector)
{
	Vector2 l_vStartDrawPos(0, 0);
	Vector2 l_vSize((float)m_pFrameBuffer->GetWidth(), (float)m_pFrameBuffer->GetHeight());
	glEnable2D((float)m_pFrameBuffer->GetWidth(), (float)m_pFrameBuffer->GetHeight());
	//RenderFilledRectangle(l_vStartDrawPos, l_vSize.x, l_vSize.y, Vector4::Green, 0.f);
	m_pFrameBuffer->StartDraw();
	//glClearColor(1, 1, 1, 1);
	//RenderFilledRectangle(l_vStartDrawPos, l_vSize.x, l_vSize.y, Vector4::Zero, 0.f);
	// Create the QR Code object
	std::string l_strText;
	for (size_t i = 0; i < e_i64ValueVector.size(); ++i)
	{
		l_strText += ValueToString(e_i64ValueVector[i]);
		if( i != e_i64ValueVector.size()-1)
			l_strText += ",";
	}
	std::string l_str = l_strText;// "a1234567890\na1234567890\na1234567890\na1234567890";
	QrCode qr = QrCode::encodeText(l_str.c_str(), QrCode::Ecc::MEDIUM);
	int l_iSize = qr.getSize();
	float l_fGap = l_vSize.x / l_iSize;
	Vector2 l_vFinalPos = Vector2(0,0);
	// Read the black & white pixels
	for (int x = 0; x < l_iSize; x++)
	{
		for (int y = 0; y < l_iSize; y++)
		{
			int color = qr.getModule(x, y);  // 0 for white, 1 for black
											 // You need to modify this part
			Vector4 l_vColor = Vector4::One;
			if (color == 0)
				l_vColor = Vector4::Zero;
			RenderFilledRectangle(l_vFinalPos, l_fGap, l_fGap, l_vColor, 0.f);
			l_vFinalPos.y += l_fGap;
		}
		l_vFinalPos.y = l_vStartDrawPos.y;
		l_vFinalPos.x += l_fGap;
	}
	m_pFrameBuffer->EndDraw();
}

void cQRImage::Render(Vector2 e_vRenderPos)
{
	if (m_pFrameBuffer)
	{
		POINT l_Pos = { (int)e_vRenderPos.x,(int)e_vRenderPos.y };
		POINT l_Size = { (int)m_pFrameBuffer->GetWidth(), (int)m_pFrameBuffer->GetHeight() };
		m_pFrameBuffer->DrawBuffer(l_Pos, l_Size);
	}
}