#pragma once

#include "UseBluetoothDoCodeReportParameter.h"
#include "../../../Core//Network/Network.h"

//step
//eBRCM_SEND_TO_SERVER_REQUEST_REPORT->
//eBRCM_SENT_TO_CLIENT_REQUEST_REPORT_RESULT->
//eBRCM_SEND_TO_SERVER_REPORT_RESULT->
//eBRCM_SENT_TO_CLIENT_REPORT_RESULT
//#define	REG_EVENT(EventID,Function)RegEvent(EventID,std::bind(Function,this,std::placeholders::_1));
class cUseBluetoothDoCodeReport : public cSingltonTemplate<cUseBluetoothDoCodeReport>,public NamedTypedObject,public cMessageSender
{
	UT::sTimeCounter	m_TimeToSendReportCodeInfo;//time's up send to player for common info
	//
	int					m_iClientConnectedCount;
	bool				m_bRequestReport;//while scene change is avtived send to client,and wait for client respone.
	sReportInfo			m_WaitForRespondInfo;
	//
	void				SendReportInfo(float e_fElpaseTime);
	void				SendRequestReportResult();
	void				SendReportResult(bool e_bResult);
	eBluetoothReportCodeMessage	m_eCurrentMessage;//while m_bRequestReport is true
	void				RequestReportUpdate(float e_fElpaseTime);
	//
	void				ProcessMessage(sBaseMessageInfo*e_pBaseMessageInfo);
	void				ProcessReportResultMessage(sBaseMessageInfo*e_pBaseMessageInfo);
	void				ProcessRequestReportMessage(sBaseMessageInfo*e_pBaseMessageInfo);
	//void				ClientConnected(SDLNet_Socket*);
	//void				ClientDisconnected(SDLNet_Socket*);
	bool				SceneChangeDoReportCode(void *e_pData);//only while scene change animation is playing
	//
	cUseBluetoothDoCodeReport();
	~cUseBluetoothDoCodeReport();
public:
	DEFINE_TYPE_INFO();
	SINGLETON_BASIC_FUNCTION(cUseBluetoothDoCodeReport);
	void	Update(float e_fElpaseTime);
	void	Render();
};

