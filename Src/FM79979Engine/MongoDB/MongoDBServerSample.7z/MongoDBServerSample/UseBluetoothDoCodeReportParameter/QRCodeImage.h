#pragma once

struct sReportInfo;
class cQRImage
{
	cFrameBuffer*m_pFrameBuffer;
	void	SetData(std::vector<int64>&e_i64ValueVector);
public:
	cQRImage(Vector2 e_vImageSize);
	~cQRImage();
	void	SetData(sReportInfo* e_pReportInfo);
	
	void	Render(Vector2 e_vRenderPos);
};


//#include "../UseBluetoothDoCodeReport/QRCodeImage.h"
//cQRImage*g_pQRImage = nullptr;
//g_pQRImage = new cQRImage(Vector2(150, 150));
//sReportInfo l_ReportInfo;
//g_pQRImage->SetData(&l_ReportInfo);
//g_pQRImage->SetData(l_DataVector);
//if (g_pQRImage)
//	g_pQRImage->Render(Vector2(300, 300));