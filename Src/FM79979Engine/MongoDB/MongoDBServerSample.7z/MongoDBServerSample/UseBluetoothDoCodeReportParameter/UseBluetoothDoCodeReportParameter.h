#pragma once


enum eBluetoothReportCodeMessage
{
	eBRCM_SENT_TO_CLIENT_REPORT_INFO = 0,//every N seconds send to client,sSendToClientReportInfo
	eBRCM_SENT_TO_CLIENT_REQUEST_REPORT_RESULT,//sSendToclientRequestReportResult
	eBRCM_SENT_TO_CLIENT_REPORT_RESULT,//1 for success 0 for failed,sSendToClientReportResult
	eBRCM_SEND_TO_SERVER_REQUEST_REPORT,//sBaseMessageInfo
	eBRCM_SEND_TO_SERVER_REPORT_RESULT,//sSendToServerReportResult
	eBRCM_MAX
};


struct sBaseMessageInfo
{
	int iMessageID;
	sBaseMessageInfo(int e_iMessageID) { iMessageID = e_iMessageID; }
};

struct sReportInfo
{
	int		iReportCount;
	int		iProductTypeNumber;
	int		iMachineID;
	int64	i64ExchangeIn;
	int64	i64ExchangeOut;
	int64	i64BulletShootCount;
	int64	i64BetMoney;				// This Total
	int64	i64WinMoney;				// This Total
	int64	i64BulletTotalShootCount;   // This Total
    int64  	i64OVERCount;
    int64	i64OVERScore;
    int64	i64GameWater;
};

inline bool GetReportInfoByString(const char*e_strText, sReportInfo& e_ReportInfo)
{
	std::wstring l_strText = ValueToStringW(e_strText);
	std::vector<int64>l_ResultVector = GetInt64ListByCommaDivide(l_strText.c_str(), 0);
	if (l_ResultVector.size() >= 12)
	{
		e_ReportInfo.iReportCount = (int)l_ResultVector[0];
		e_ReportInfo.iProductTypeNumber = (int)l_ResultVector[1];
		e_ReportInfo.iMachineID = (int)l_ResultVector[2];
		e_ReportInfo.i64ExchangeIn = l_ResultVector[3];
		e_ReportInfo.i64ExchangeOut = l_ResultVector[4];
		e_ReportInfo.i64BulletShootCount = l_ResultVector[5];
		e_ReportInfo.i64BetMoney = l_ResultVector[6];
		e_ReportInfo.i64WinMoney = l_ResultVector[7];
		e_ReportInfo.i64BulletTotalShootCount = l_ResultVector[8];
		e_ReportInfo.i64OVERCount = l_ResultVector[9];
		e_ReportInfo.i64OVERScore = l_ResultVector[10];
		e_ReportInfo.i64GameWater = l_ResultVector[11];
		return true;
	}
	return false;
}


struct sSendToClientReportInfo:public sBaseMessageInfo
{
	sReportInfo	ReportInfo;
	sSendToClientReportInfo():sBaseMessageInfo(eBRCM_SENT_TO_CLIENT_REPORT_INFO){}
	~sSendToClientReportInfo(){}
};

struct sSendToclientRequestReportResult :public sBaseMessageInfo
{
	sReportInfo	ReportInfo;
	sSendToclientRequestReportResult():sBaseMessageInfo(eBRCM_SENT_TO_CLIENT_REQUEST_REPORT_RESULT) {}
};

struct sSendToServerReportResult :public sBaseMessageInfo
{
	int		iCodeLnegth;
	char	cCode[100];//I donno exzactly length,assume 100 is enough
	sSendToServerReportResult():sBaseMessageInfo(eBRCM_SEND_TO_SERVER_REPORT_RESULT){}
};
//
struct sSendToClientReportResult:public sBaseMessageInfo
{
	bool bResult;
	sSendToClientReportResult():sBaseMessageInfo(eBRCM_SENT_TO_CLIENT_REPORT_RESULT){}
};