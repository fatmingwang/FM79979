#include "stdafx.h"
#include "UseBluetoothDoCodeReport.h"
#include "../GameDefine/FishGameEventMessageID.h"
#include "../../../Core/Bluetooth/Bluetooth.h"
#include "../ControlPanel/ControlSettingParameter.h"
#include "../ControlPanel/CSetTypeNumber.h"
#include "../ControlPanel/CCodeReport.h"
#include "../Player/PlayerManager.h"
TYPDE_DEFINE_MARCO(cUseBluetoothDoCodeReport)
cUseBluetoothDoCodeReport::cUseBluetoothDoCodeReport()
{
	REG_EVENT(eFGEMI_SCENE_CHANGE_FOR_BLUETOOTH_DO_CODE_REPORT, &cUseBluetoothDoCodeReport::SceneChangeDoReportCode);
	memset(&m_WaitForRespondInfo, -1, sizeof(m_WaitForRespondInfo));
	m_TimeToSendReportCodeInfo.SetTargetTime(1.5f);
	cBluetoothSinglton::GetInstance()->Init();
	cControlPanelSinglton* l_pControlPanel = cControlPanelSinglton::GetInstance();
	cBluetoothSinglton::GetInstance()->CreateAsServer(l_pControlPanel->GetMachineNumber().c_str());
	m_iClientConnectedCount = 0;
	auto l_ClientAdd = [this](SDLNet_Socket*e_pSDLNet_Socket)
	{
		++m_iClientConnectedCount;
	};
	auto l_ClientRemove = [this](SDLNet_Socket*e_pSDLNet_Socket)
	{
		--m_iClientConnectedCount;
		if (m_iClientConnectedCount < 1)
			m_bRequestReport = false;
	};
	auto l_LostConnection = [this](SDLNet_Socket*e_pSDLNet_Socket)
	{
		m_iClientConnectedCount = 0;
	};
	cBluetoothSinglton::GetInstance()->SetSocketFunction(l_ClientAdd, l_ClientRemove, l_LostConnection, nullptr);
}

cUseBluetoothDoCodeReport::~cUseBluetoothDoCodeReport()
{
	cBluetoothSinglton::DestroyInstance();
}

sReportInfo	GetReportInfo()
{
	cPlayerManagerSinglton*l_pPlayerManagerSinglton = cPlayerManagerSinglton::GetInstance();
	sPlayerScroeData* l_pPlayerScroeData = nullptr;
	if (l_pPlayerManagerSinglton)
		l_pPlayerScroeData = l_pPlayerManagerSinglton->GetPlayerScroeData();
	cControlPanelSinglton* l_pControlPanel = cControlPanelSinglton::GetInstance();
	sControlPanelSingltonSaveData lsTempControlPanelSingltonSaveData = l_pControlPanel->GetSaveData();
	sTotalPlayerScroeData lTempNowTotalPlayerScroeData;
	l_pControlPanel->GetCurrentTotalPlayerScroeData(lTempNowTotalPlayerScroeData);
	CSetTypeNumber* lpSetTypeNumber = (CSetTypeNumber*)l_pControlPanel->GetPage(cControlPanelSinglton::ePageSetTypeNumber);
	sReportInfo l_ReportInfo;
	l_ReportInfo.i64ExchangeIn = lTempNowTotalPlayerScroeData.m_i64ExchangeIn;
	l_ReportInfo.i64ExchangeOut = lTempNowTotalPlayerScroeData.m_i64ExchangeOut;
	l_ReportInfo.iMachineID = _wtoi(l_pControlPanel->GetMachineNumber().c_str());
	l_ReportInfo.iProductTypeNumber = lpSetTypeNumber->GetTypeNumber();
	l_ReportInfo.iReportCount = lsTempControlPanelSingltonSaveData.m_nReportCount;
	l_ReportInfo.i64BetMoney = lTempNowTotalPlayerScroeData.m_i64BetScore + lsTempControlPanelSingltonSaveData.m_sPreviousTotal_TotalPlayerScroeData.m_i64BetScore;
	l_ReportInfo.i64WinMoney = lTempNowTotalPlayerScroeData.m_i64WinScore + lsTempControlPanelSingltonSaveData.m_sPreviousTotal_TotalPlayerScroeData.m_i64WinScore;


	if (l_pPlayerScroeData)
	{
		l_ReportInfo.i64BulletTotalShootCount = lsTempControlPanelSingltonSaveData.m_sPreviousTotalBulletFireCount + l_pPlayerScroeData->m_i64TotalBulletFireCount;
		l_ReportInfo.i64BulletShootCount = l_pPlayerScroeData->m_i64TotalBulletFireCount;
	}

	l_ReportInfo.i64OVERCount = lTempNowTotalPlayerScroeData.m_i64OVERCount;
	l_ReportInfo.i64OVERScore = lTempNowTotalPlayerScroeData.m_i64OVERScore;
	l_ReportInfo.i64GameWater = (int64)PROBABILITY_GetNormalPumpingWater();

    if (0 != sControlPannelSettingParameter::m_siCoinRatio)
    {
        double lCoinRatioActual = ((double)sControlPannelSettingParameter::m_siCoinRatio) / DefCoinRatio_Magnification;
        l_ReportInfo.i64ExchangeIn = (int64)(((double)l_ReportInfo.i64ExchangeIn / lCoinRatioActual) + 0.5f);
        l_ReportInfo.i64ExchangeOut = (int64)(((double)l_ReportInfo.i64ExchangeOut / lCoinRatioActual) + 0.5f);
        l_ReportInfo.i64OVERScore = (int64)(((double)l_ReportInfo.i64OVERScore / lCoinRatioActual) + 0.5f);
    }
	return l_ReportInfo;
}

void cUseBluetoothDoCodeReport::SendReportInfo(float e_fElpaseTime)
{
	if (m_iClientConnectedCount>0)
	{
		m_TimeToSendReportCodeInfo.Update(e_fElpaseTime);
		if (m_TimeToSendReportCodeInfo.bTragetTimrReached)
		{
			m_TimeToSendReportCodeInfo.Start();
			sSendToClientReportInfo l_SendToClientReportInfo;
			l_SendToClientReportInfo.ReportInfo = GetReportInfo();
			m_WaitForRespondInfo = l_SendToClientReportInfo.ReportInfo;
            int l_iSize = (int)sizeof(sSendToClientReportInfo);
			cBluetoothSinglton::GetInstance()->SendDataToAllClient(l_iSize,(char*)&l_SendToClientReportInfo);
		}
	}
}


//sSendToclientRequestReportResult

void cUseBluetoothDoCodeReport::SendRequestReportResult()
{
	sSendToclientRequestReportResult l_SendToclientRequestReportResult;
	int l_iSize = (int)sizeof(sSendToclientRequestReportResult);
	l_SendToclientRequestReportResult.ReportInfo = GetReportInfo();
    cBluetoothSinglton::GetInstance()->SendDataToAllClient(l_iSize, (char*)&l_SendToclientRequestReportResult);
}

void cUseBluetoothDoCodeReport::SendReportResult(bool e_bResult)
{
	sSendToClientReportResult l_SendToClientReportResult;
	int l_iSize = (int)sizeof(sSendToClientReportResult);
	l_SendToClientReportResult.bResult = e_bResult;
	cBluetoothSinglton::GetInstance()->SendDataToAllClient(l_iSize, (char*)&l_SendToClientReportResult);
}

void	cUseBluetoothDoCodeReport::ProcessMessage(sBaseMessageInfo*e_pBaseMessageInfo)
{
	if (m_iClientConnectedCount == 0)
	{
		return;
	}
	switch (e_pBaseMessageInfo->iMessageID)
	{
		//case eBRCM_SENT_TO_CLIENT_REPORT_INFO:
		//case eBRCM_SENT_TO_CLIENT_REQUEST_REPORT_RESULT:
		//case eBRCM_SENT_TO_CLIENT_REPORT_RESULT:
		case eBRCM_SEND_TO_SERVER_REQUEST_REPORT:
			ProcessRequestReportMessage(e_pBaseMessageInfo);
			break;
		case eBRCM_SEND_TO_SERVER_REPORT_RESULT:
			ProcessReportResultMessage(e_pBaseMessageInfo);
			break;
		default:
			assert(0&&"wrong message!?");
			break;
	}
}

void	cUseBluetoothDoCodeReport::ProcessReportResultMessage(sBaseMessageInfo*e_pBaseMessageInfo)
{
	sSendToServerReportResult*l_pSendToServerReportResult = (sSendToServerReportResult*)e_pBaseMessageInfo;
    cControlPanelSinglton* l_pControlPanel = cControlPanelSinglton::GetInstance();
    CCodeReport* lpCodeReport = (CCodeReport*)l_pControlPanel->GetPage(cControlPanelSinglton::ePageCodeReport);

	bool l_bResult = false;//lpCodeReport->CompareReportCodeWithParameter(l_pSendToServerReportResult->iCodeLnegth, l_pSendToServerReportResult->cCode);
	{
		cControlPanelSinglton* l_pControlPanel = cControlPanelSinglton::GetInstance();
		cPlayerManagerSinglton*l_pPlayerManagerSinglton = cPlayerManagerSinglton::GetInstance();
		sControlPanelSingltonSaveData lsTempControlPanelSingltonSaveData = l_pControlPanel->GetSaveData();
		CSetTypeNumber* lpSetTypeNumber = (CSetTypeNumber*)l_pControlPanel->GetPage(cControlPanelSinglton::ePageSetTypeNumber);
		// Machine Number
		FISG_GAME_PARAMETERIZE::sTwLeadStreamProductData  lsTempTwLeadStreamProductData;
		lsTempTwLeadStreamProductData.iMachineID = _wtoi(l_pControlPanel->GetMachineNumber().c_str());
		lsTempTwLeadStreamProductData.iProductTypeNumber = lpSetTypeNumber->GetTypeNumber();
		char l_cPhoneDataBuffer[99];
		memset(l_cPhoneDataBuffer, 0, sizeof(l_cPhoneDataBuffer));

		FISG_GAME_PARAMETERIZE::GenerateReportCode(l_cPhoneDataBuffer, m_WaitForRespondInfo.i64ExchangeIn, m_WaitForRespondInfo.i64ExchangeOut,m_WaitForRespondInfo.i64BulletShootCount,
			m_WaitForRespondInfo.iReportCount,lsTempTwLeadStreamProductData);
		l_bResult = FISG_GAME_PARAMETERIZE::CompareReportCodeWithParameter(l_cPhoneDataBuffer, l_pSendToServerReportResult->cCode);
	}
    if (l_bResult)
    { 
        l_pControlPanel->GameReport();
        CCodeReport::sAddSaveRecordParameter lAddSaveRecordParameter;
        lAddSaveRecordParameter.bMobilePhone = true;
        lpCodeReport->AddSaveRecord(lAddSaveRecordParameter);
    }

	SendReportResult(l_bResult);
	memset(&m_WaitForRespondInfo, -1, sizeof(m_WaitForRespondInfo));
}

void cUseBluetoothDoCodeReport::ProcessRequestReportMessage(sBaseMessageInfo * e_pBaseMessageInfo)
{
	this->m_bRequestReport = true;
}

bool cUseBluetoothDoCodeReport::SceneChangeDoReportCode(void * e_pData)
{
	if (this->m_bRequestReport && m_iClientConnectedCount)
	{
		SendRequestReportResult();
		m_bRequestReport = false;
	}
	return false;
}

void cUseBluetoothDoCodeReport::Update(float e_fElpaseTime)
{
	std::vector<sBluetoothPacket*> l_DataVector;
	cBluetoothSinglton::GetInstance()->GetReceivedData(&l_DataVector);
	size_t l_uiSize = l_DataVector.size();
	for (size_t i = 0; i < l_uiSize; i++)
	{
		auto l_pData = l_DataVector[i];
		sBaseMessageInfo*l_pBaseMessageInfo = (sBaseMessageInfo*)l_pData->pData;
		ProcessMessage(l_pBaseMessageInfo);
		delete l_pData;
	}
	SendReportInfo(e_fElpaseTime);
}

void cUseBluetoothDoCodeReport::Render()
{
	cBluetoothSinglton::GetInstance()->Render(900,200);
}