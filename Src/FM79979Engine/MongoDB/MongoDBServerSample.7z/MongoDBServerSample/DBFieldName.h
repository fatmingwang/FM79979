#pragma once


//User collection
#define USER_ID						"ID"
#define PASSWORD					"PWD"
#define AUTHORITY					"Authority"
#define	DESCRIPTION					"Description"
#define	MACHINELIST					"MachineList"

//each user's machine report history collection
#define	MACHINE_ID					"MachineID"
#define	MACHINE_REPORT_DATA_ARRAY	"ReportDataArray"


//code report field name
#define  CODE_REPORT_VERSION					"Ver"
#define  CODE_REPORT_REPORT_COUNT				"iReportCount"
#define  CODE_REPORT_PRODUCT_TYPE_NUMBER		"iProductTypeNumber"
#define  CODE_REPORT_MACHINE_ID					"iMachineID"
#define  CODE_REPORT_EXCHANGE_IN				"i64ExchangeIn"
#define  CODE_REPORT_EXCHANGE_OUT				"i64ExchangeOut"
#define  CODE_REPORT_BULLET_SHOOT_COUNT			"i64BulletShootCount"
#define  CODE_REPORT_BET_MONEY					"i64BetMoney"
#define  CODE_REPORT_WIN_MONEY					"i64WinMoney"
#define  CODE_REPORT_BULLET_TOTAL_SHOOT_COUNT	"i64BulletTotalShootCount"
#define  CODE_REPORT_OVER_COUNT					"i64OVERCount"
#define  CODE_REPORT_OVER_SCORE					"i64OVERScore"
#define  CODE_REPORT_GAME_WATER					"i64GameWater"