#pragma once

#include "MongoDBHeader.h"
#include "EventMessage.h"
#include "DB_CURDStruct.h"
#include "User.h"

//DB structure
//User collection
//name,ID,own machine(array)
//
//customer collections(each user has its own collection and collection name is userID)
//ReportData:{time,reportcode}
//
//

//http://mongocxx.org/mongocxx-v3/tutorial/

class cMongoDB:public cMessageSender , public FATMING_CORE::cCPP11Thread
{
	void	TestCode();
	//
	mongocxx::database						m_FishDatabase;
	mongocxx::instance						m_Instance;
	mongocxx::collection					m_UserDataCollection;
	std::map<int,mongocxx::collection>		m_UserIDAndCollectionPointerMap;
	//
	std::string								m_strIPAndPort;
	std::string								m_strUserName;
	std::string								m_strPWD;
	//
	//all user cannt connect ti server now.
	bool									m_bRefreshDataFromDB = true;
	bool									m_bInitMongoDB;
	void									Refresh();
	void									MongoDBInit();
	void									UserCollectionInit();
	bool									UserDataProcess(bsoncxx::v_noabi::document::view&e_Element,sUserDataInUserCollection&e_UserDataInUserCollection);
	bool									UserReportInfoDataProcess(bsoncxx::v_noabi::document::view&e_View, sUserDataInUserCollection&e_UserDataInUserCollection);
	//bind a key up to refresh data?
	bool									RefreshUserCollectionEvent(void*e_pData);
	void									ThreadUpdate(float e_fElpaseTime);
	mongocxx::collection*					FetchCollectionByName(const char*e_strName);
	//
	bool									AdminAuthoirtyCheck(sCURD_DataBase*e_pCURD_DataBase, cUser*e_pConnectedUser);
	bool									Process_eDB_CURD_CREATE_USER(sCURD_CreateUser*e_pCURD_Data, cUser*e_pConnectedUser);
	bool									Process_eDB_CURD_UPDATE_USER(sCURD_UpdateUser*e_pCURD_Data, cUser*e_pConnectedUser);
	bool									Process_eDB_CURD_DELETE_USER(sCURD_DeleteUser*e_pCURD_Data, cUser*e_pConnectedUser);
	bool									Process_eDB_CURD_UPDATE_USER_MACHINE(sCURD_UpdateUser_Machine*e_pCURD_Data, cUser*e_pConnectedUser);
	bool									Process_eDB_CURD_ADD_REPORT_DATA(sCURD_AddReportData*e_pCURD_Data, cUser*e_pConnectedUser);
	bool									Process_DB_CURD(sCURD_DataBase*e_pCURD_DataBase);
	//
	cUser*									UserValidate(sCURD_DataBase*e_pCURD_DataBase);
	//
	std::vector<sCURD_DataBase*>			m_QueryDataVector;
	std::mutex								m_QueryDataVectorMutex;
public:
	cMongoDB();
	~cMongoDB();
	//ConnectToDBServer("10.168.1.143:27017/", "fatming", "1234");
	void	ConnectToDBServer(const char*e_strIPAndPort,const char*e_strUserName,const char*e_strPWD);
	std::vector<int>						GetMachineArrayByUserID();
	bool									IsRefreshDataFromDB() { return m_bRefreshDataFromDB; }
	void									SetRefreshDataFromDB(bool e_b);
	void									AddQueryData(sCURD_DataBase*e_pCURD_DataBase);
};

void										AddQueryDataIntoDBQueryVector(sCURD_DataBase*e_pCURD_DataBase);