#pragma once

#include "../Core/Network/GameNetWork.h"
#include "EventMessage.h"

class cUserVector;
class cNetworkBrain:public cGameNetwork,public cMessageSender
{
	std::mutex								m_WaitForRespondNetworkMessageMutex;
	std::vector<struct sBaseNetworkMessage*>m_WaitForRespondNetworkMessageVector;

	void								ClientLostConnection(_TCPsocket*e_pSocket);
	//event
	bool								RefreshUserCollectionFromMongoDBFinishEvent(void*e_pData);
	bool								RefreshUserCollectionFromMongoDBStartEvent(void*e_pData);
	//network message
	bool								NetworkMessage_eNM_C2S_LOGIN_REQUEST(FATMING_CORE::sNetworkReceivedPacket*e_pNetworkReceivedPacket);
	bool								NetworkMessage_eNM_C2S_ADD_USER_REQUEST(FATMING_CORE::sNetworkReceivedPacket*e_pNetworkReceivedPacket);
	bool								NetworkMessage_eNM_C2S_DELETE_USER_REQUEST(FATMING_CORE::sNetworkReceivedPacket*e_pNetworkReceivedPacket);
	bool								NetworkMessage_eNM_C2S_UPDATE_USER_REQUEST(FATMING_CORE::sNetworkReceivedPacket*e_pNetworkReceivedPacket);
	bool								NetworkMessage_eNM_C2S_UPDATE_USER_OWN_MACHINE_REQUEST(FATMING_CORE::sNetworkReceivedPacket*e_pNetworkReceivedPacket);
	bool								NetworkMessage_eNM_C2S_DO_CODE_REPORT_REQUEST(FATMING_CORE::sNetworkReceivedPacket*e_pNetworkReceivedPacket);
	bool								NetworkMessage_eNM_C2S_QUERY_MACHINE_HISTORY_REQUEST(FATMING_CORE::sNetworkReceivedPacket*e_pNetworkReceivedPacket);
	//
	bool								AdminAuthorityAndTargetUserCheck(const char*e_strAdminID,const char*e_strTargetID, FATMING_CORE::sNetworkReceivedPacket * e_pNetworkReceivedPacket, const char*e_strPrefixMessage);
	//
	bool								SendMessageToClient(FATMING_CORE::sNetworkReceivedPacket*e_pNetworkReceivedPacket, struct sBaseNetworkMessage*e_pBaseNetworkMessage);
	bool								SendMessageToClient(_TCPsocket*e_pTCPsocket, struct sBaseNetworkMessage*e_pBaseNetworkMessage);
public:
	cNetworkBrain();
	~cNetworkBrain();
	virtual void						Update(float e_fElpaseTime);
	virtual void						Destroy()override;
	//
	void								AddWaitForRespondNetworkMessage(struct sBaseNetworkMessage*e_pBaseNetworkMessage);
};

void			AddWaitForRespondNetworkMessage(struct sBaseNetworkMessage*e_pBaseNetworkMessage);