#include "stdafx.h"
#include "MongoDB.h"
#include "User.h"
#include "EventMessage.h"
#include <locale>
#include <codecvt>
#include <string>
#include "DBFieldName.h"
#include "MongoDBCommonFunction.h"
#include "SrcDBServerSrcMongoDBServerFishGameParameterize/FishGameParameterize.h"
#include  "SharedProtocal/NetworkMessage.h"
#include "NetworkBrain.h"
#if defined(WIN32)
#pragma warning( disable : 4996 )
#endif
//https://www.twblogs.net/a/5b8776e72b71775d1cd74f61
//add new data or update data
//		auto l_Result = m_UserDataCollection.update_one(
//document{} << "Name" << "1" << finalize,
//document{} << "$set" << open_document << "TestData" << "28825252" << close_document << finalize
//);
//https://docs.mongodb.com/manual/reference/operator/update-field/
//auto l_Result = m_UserDataCollection.update_one(
//	document{} << "Name" << "1" << finalize,
//	document{} << "$unset" << open_document << "TestData" << "28825252" << close_document << finalize
//);

void	MongoDBCURDDumpLogAndAddWaitForRespondNetworkMessage(sBaseNetworkResultMessage*e_pBaseNetworkResultMessage, std::string&e_strBehaviorMessage)
{
	std::string l_strLog;
	if (e_pBaseNetworkResultMessage->iResultCode == eNRC_OK)
		l_strLog += "Ok ";
	else
		l_strLog += "Error ";
	l_strLog += UT::ComposeMsgByFormat("ResultCode:%d,",e_pBaseNetworkResultMessage->iResultCode);
	l_strLog += e_strBehaviorMessage;
	FMLog::LogWithFlag(l_strLog.c_str(), LOG_ID_MONGO_DB, true);
	AddWaitForRespondNetworkMessage(e_pBaseNetworkResultMessage);
}

bool cMongoDB::Process_DB_CURD(sCURD_DataBase*e_pCURD_DataBase)
{
	auto l_pUser = UserValidate(e_pCURD_DataBase);
	if (!l_pUser)
	{
		return false;
	}
	switch (e_pCURD_DataBase->DBcurdType)
	{
		case eDB_CURD_CREATE_USER:
			Process_eDB_CURD_CREATE_USER((sCURD_CreateUser*)e_pCURD_DataBase, l_pUser);
			break;
		case eDB_CURD_UPDATE_USER:
			Process_eDB_CURD_UPDATE_USER((sCURD_UpdateUser*)e_pCURD_DataBase, l_pUser);
			break;
		case eDB_CURD_DELETE_USER:
			Process_eDB_CURD_DELETE_USER((sCURD_DeleteUser*)e_pCURD_DataBase, l_pUser);
			break;
		case eDB_CURD_UPDATE_USER_MACHINE:
			Process_eDB_CURD_UPDATE_USER_MACHINE((sCURD_UpdateUser_Machine*)e_pCURD_DataBase, l_pUser);
			break;
		case eDB_CURD_ADD_REPORT_DATA:
			Process_eDB_CURD_ADD_REPORT_DATA((sCURD_AddReportData*)e_pCURD_DataBase, l_pUser);
			break;
		default:
			break;

	}
	return false;
}
bool	cMongoDB::AdminAuthoirtyCheck(sCURD_DataBase*e_pCURD_DataBase, cUser*e_pConnectedUser)
{
	auto l_UserData = e_pConnectedUser->GetUserData();
	eUserAuthority l_eUserAuthority = l_UserData.m_eUserAuthority;
	if (eUserAuthority::eUA_ADMIN != l_eUserAuthority)
	{
		FMLog::LogWithFlag(
			UT::ComposeMsgByFormat("Error cMongoDB::Process_eDB_CURD_CREATE_USER:%s authority(%d) is not permit,message is %d", e_pCURD_DataBase->strID.c_str(), (int)l_eUserAuthority,(int)e_pCURD_DataBase->DBcurdType)
			, LOG_ID_MONGO_DB, true);
		return false;
	}
	return true;
}

//https://github.com/mongodb/docs-cxx/blob/master/source/quick-start.txt
bool cMongoDB::Process_eDB_CURD_CREATE_USER(sCURD_CreateUser * e_pCURD_Data, cUser*e_pConnectedUser)
{
	sAddUserMessage_eNM_C2S_ADD_USER_RESULT*l_pAddUserMessage_eNM_C2S_ADD_USER_RESULT = new sAddUserMessage_eNM_C2S_ADD_USER_RESULT();
	sprintf(l_pAddUserMessage_eNM_C2S_ADD_USER_RESULT->strID, "%s", e_pCURD_Data->strID.c_str());
	std::string l_strBehaviorMessage = UT::ComposeMsgByFormat("cMongoDB::Process_eDB_CURD_CREATE_USER:%s(%s) add user %s,PWD:%s,Description:%s",
		e_pCURD_Data->strID.c_str(),
		e_pConnectedUser->GetUserData().strDescription.c_str(),
		e_pCURD_Data->strCreateID.c_str(),
		e_pCURD_Data->strPWD.c_str(),
		e_pCURD_Data->strDescription.c_str());
	if (AdminAuthoirtyCheck(e_pCURD_Data, e_pConnectedUser))
	{
		GET_USER_VECTOR_INSTANCE_AND_DO_MUTEX(l_pUserVector);
		if (l_pUserVector->GetObject(e_pCURD_Data->strCreateID.c_str()))
		{
			l_pAddUserMessage_eNM_C2S_ADD_USER_RESULT->iResultCode = eNetworkResultCode::eNRC_CURD_USER_EXISTS;
			l_strBehaviorMessage += "user already exists";
		}
		else
		{
			auto builder = bsoncxx::builder::stream::document{};
			std::string l_strDescription = e_pCURD_Data->strDescription;
			bsoncxx::document::value doc_value = builder
				<< USER_ID << e_pCURD_Data->strCreateID.c_str()
				<< PASSWORD << e_pCURD_Data->strPWD.c_str()
				<< DESCRIPTION << l_strDescription.c_str()
				<< MACHINELIST << bsoncxx::builder::stream::open_array
				<< close_array
				<< bsoncxx::builder::stream::finalize;
			try
			{
				auto l_Result = this->m_UserDataCollection.insert_one(doc_value.view());
				int l_iInsertCount = l_Result->result().inserted_count();
				if (l_iInsertCount != 1)
				{
					l_strBehaviorMessage += "DB insert_one add new user failed";
					l_pAddUserMessage_eNM_C2S_ADD_USER_RESULT->iResultCode = eNetworkResultCode::eNRC_CURD_DB_INSERT_ERROR;
				}
				else
				{
					l_pAddUserMessage_eNM_C2S_ADD_USER_RESULT->iResultCode = eNetworkResultCode::eNRC_OK;
				}
			}
			catch (std::exception e)
			{
				l_pAddUserMessage_eNM_C2S_ADD_USER_RESULT->iResultCode = eNetworkResultCode::eNRC_CURD_DB_EXCEPTION;
				l_strBehaviorMessage += " DB exception";
				l_strBehaviorMessage += e.what();
			}
		}
	}
	else
	{
		l_pAddUserMessage_eNM_C2S_ADD_USER_RESULT->iResultCode = eNetworkResultCode::eNRC_AUTHORITY_NOT_PERMIT;
		l_strBehaviorMessage += "Authority not permit";
	}
	MongoDBCURDDumpLogAndAddWaitForRespondNetworkMessage(l_pAddUserMessage_eNM_C2S_ADD_USER_RESULT, l_strBehaviorMessage);
	return true;
}
//https://stackoverflow.com/questions/49715777/mongodb-c-update-array-and-add-element
//{
//	"_id" : ObjectId("5ac4beacc0e2a512e6377d43"),
//		"document" : "test",
//		"user" : [
//	{
//		"email" : "a@gmail.com",
//			"username" : "Anton Held",
//			"job" : "",
//	},
//			{
//				"email" : "b@gmail.com",
//				"username" : "Benny Bill",
//				"job" : "IT-Officer",
//			},
//			{
//				"email" : "c@gmail.com",
//				"username" : "Conny Cenn",
//				"job" : "",
//			},
//		]
//}
//db command
//db.getCollection("testcollection").update(
	//{"document":"test", "user.email" : "a@gmail.com"},
	//{ "$set": {"user.$.username":"New Username"} }
	//)
//c++ code
//collection.update_one(
//	document{} << "document" << "test"
//	<< "user.email" << "a@gmail.com"
//	<< finalize,
//	document{} << "$set"
//	<< open_document
//	<< "user.$.username" << "New Username"
//	<< close_document << finalize
//);
bool cMongoDB::Process_eDB_CURD_UPDATE_USER(sCURD_UpdateUser * e_pCURD_Data, cUser*e_pConnectedUser)
{
	sUpdateUserDataInfo_eNM_C2S_UPDATE_USER_RESULT*l_pUpdateUserDataInfo_eNM_C2S_UPDATE_USER_RESULT = new sUpdateUserDataInfo_eNM_C2S_UPDATE_USER_RESULT();
	sprintf(l_pUpdateUserDataInfo_eNM_C2S_UPDATE_USER_RESULT->strID, "%s", e_pCURD_Data->strID.c_str());
	std::string l_strBehaviorMessage = UT::ComposeMsgByFormat("cMongoDB::Process_eDB_CURD_UPDATE_USER:%s update %s,old PWD:%s,%s,Description:%s,%s", 
		e_pCURD_Data->strID.c_str(),
		e_pCURD_Data->strTargetID.c_str(),
		e_pCURD_Data->strPWD.c_str(),
		e_pCURD_Data->strNewPWD.c_str(),
		e_pCURD_Data->strDescription.c_str(),
		e_pConnectedUser->GetUserData().strDescription.c_str());
	if (AdminAuthoirtyCheck(e_pCURD_Data, e_pConnectedUser))
	{
		try
		{
			auto l_UserData = e_pConnectedUser->GetUserData();
			bsoncxx::stdx::optional<bsoncxx::document::value> l_UserDoc = m_UserDataCollection.find_one(document{} << USER_ID << e_pCURD_Data->strTargetID.c_str() << finalize);
			if (l_UserDoc)
			{
				if (!strcmp(e_pCURD_Data->strPWD.c_str(), l_UserData.strPWD.c_str()))
				{
					bsoncxx::document::view_or_value l_Filter = document{} << USER_ID << e_pCURD_Data->strTargetID.c_str() << finalize;
					const int l_iModifyCount = 2;
					std::string l_strTarget[l_iModifyCount] = { PASSWORD,DESCRIPTION };
					const char*l_strNewData[l_iModifyCount] = { e_pCURD_Data->strNewPWD.c_str(),e_pCURD_Data->strDescription.c_str() };
					const char*l_strOldData[l_iModifyCount] = { l_UserData.strPWD.c_str(),l_UserData.strDescription.c_str() };
					l_pUpdateUserDataInfo_eNM_C2S_UPDATE_USER_RESULT->iResultCode = eNetworkResultCode::eNRC_OK;
					for (int i = 0; i < l_iModifyCount; ++i)
					{
						//fuck use replaceOne instead update_one.
						//https://docs.mongodb.com/manual/reference/method/db.collection.replaceOne/#db.collection.replaceOne
						auto l_Result1 = m_UserDataCollection.update_one(l_Filter,
							document{} << "$set" << open_document << l_strTarget[i] << l_strNewData[i] << close_document << finalize);
						std::string l_strLog;
						if (l_Result1->matched_count() == 1 && l_Result1->modified_count() == 1)
						{
							l_strBehaviorMessage += UT::ComposeMsgByFormat("Ok %s:old:%s,new:%s", l_strTarget[i].c_str(),
								l_strOldData[i], l_strNewData[i]);
						}
						else
						{
							l_strBehaviorMessage += UT::ComposeMsgByFormat("Error %s:old:%s,new:%s", l_strTarget[i].c_str(),
								l_strOldData[i], l_strNewData[i]);
							l_pUpdateUserDataInfo_eNM_C2S_UPDATE_USER_RESULT->iResultCode = eNetworkResultCode::eNRC_CURD_DB_UPDATE_ERROR;
						}
					}
				}
				else
				{
					l_pUpdateUserDataInfo_eNM_C2S_UPDATE_USER_RESULT->iResultCode = eNetworkResultCode::eNRC_USER_PWD_NOT_MATCH_ERROR;
					l_strBehaviorMessage += "PWD not match";
				}
			}
			else
			{
				l_pUpdateUserDataInfo_eNM_C2S_UPDATE_USER_RESULT->iResultCode = eNetworkResultCode::eNRC_CURD_USER_NOT_EXISTS;
				l_strBehaviorMessage += "user not exists! ";
			}
		}
		catch (std::exception e)
		{
			l_pUpdateUserDataInfo_eNM_C2S_UPDATE_USER_RESULT->iResultCode = eNetworkResultCode::eNRC_CURD_DB_EXCEPTION;
			l_strBehaviorMessage += " DB exception! ";
			l_strBehaviorMessage += e.what();
		}
	}
	else
	{
		l_pUpdateUserDataInfo_eNM_C2S_UPDATE_USER_RESULT->iResultCode = eNetworkResultCode::eNRC_AUTHORITY_NOT_PERMIT;
		l_strBehaviorMessage += " authority not enough";
		l_strBehaviorMessage += ValueToString((int)e_pConnectedUser->GetUserData().m_eUserAuthority);
	}
	MongoDBCURDDumpLogAndAddWaitForRespondNetworkMessage(l_pUpdateUserDataInfo_eNM_C2S_UPDATE_USER_RESULT, l_strBehaviorMessage);
	return true;
}

bool cMongoDB::Process_eDB_CURD_DELETE_USER(sCURD_DeleteUser * e_pCURD_Data, cUser*e_pConnectedUser)
{
	sDeleteUserMessage_eNM_S2C_DELETE_USER_RESULT*l_pDeleteUserMessage_eNM_S2C_DELETE_USER_RESULT = new sDeleteUserMessage_eNM_S2C_DELETE_USER_RESULT;
	sprintf(l_pDeleteUserMessage_eNM_S2C_DELETE_USER_RESULT->strID, "%s", e_pCURD_Data->strID.c_str());
	std::string l_strBehaviorMessage = UT::ComposeMsgByFormat("cMongoDB::Process_eDB_CURD_DELETE_USER:%s delete %s", e_pCURD_Data->strID.c_str(), e_pCURD_Data->strDeleteID.c_str());
	if (AdminAuthoirtyCheck(e_pCURD_Data, e_pConnectedUser))
	{
		GET_USER_VECTOR_INSTANCE_AND_DO_MUTEX(l_pUserVector);
		auto l_pUser = l_pUserVector->GetObject(e_pCURD_Data->strDeleteID.c_str());
		if (!l_pUser)
		{
			l_strBehaviorMessage += "no such user:";
			l_pDeleteUserMessage_eNM_S2C_DELETE_USER_RESULT->iResultCode = eNetworkResultCode::eNRC_CURD_USER_NOT_EXISTS;
		}
		else
		{
			bsoncxx::stdx::optional<bsoncxx::document::value> l_UserDoc = m_UserDataCollection.find_one(document{} << USER_ID << e_pCURD_Data->strID.c_str() << finalize);
			if (l_UserDoc)
			{
				auto l_UserData = l_pUser->GetUserData();
				if (!strcmp(e_pCURD_Data->strPWD.c_str(), l_UserData.strPWD.c_str()))
				{
					auto l_PWDElement = l_UserDoc->view()[e_pCURD_Data->strPWD.c_str()];
					try
					{
						auto l_Result = m_UserDataCollection.delete_one(document{} << USER_ID << e_pCURD_Data->strDeleteID.c_str() << finalize);
						if (l_Result->result().deleted_count() == 1)
						{
							l_pDeleteUserMessage_eNM_S2C_DELETE_USER_RESULT->iResultCode = eNetworkResultCode::eNRC_OK;
						}
						else
						{
							l_pDeleteUserMessage_eNM_S2C_DELETE_USER_RESULT->iResultCode = eNetworkResultCode::eNRC_CURD_DB_DELETE_ERROR;
							l_strBehaviorMessage += "DB delete_one failed";
						}
					}
					catch (std::exception e)
					{
						l_strBehaviorMessage += "DB delete_one exception";
						l_strBehaviorMessage += e.what();
						l_pDeleteUserMessage_eNM_S2C_DELETE_USER_RESULT->iResultCode = eNetworkResultCode::eNRC_CURD_DB_EXCEPTION;
					}
				}
				else
				{
					l_strBehaviorMessage += " PWD not matched,";
					l_strBehaviorMessage += e_pCURD_Data->strPWD;
					l_pDeleteUserMessage_eNM_S2C_DELETE_USER_RESULT->iResultCode = eNetworkResultCode::eNRC_USER_PWD_NOT_MATCH_ERROR;
				}
			}
			else
			{
				l_strBehaviorMessage += "DB find_one not find anything";
				l_pDeleteUserMessage_eNM_S2C_DELETE_USER_RESULT->iResultCode = eNetworkResultCode::eNRC_CURD_DB_FIND_ONE_ERROR;
			}
		}
	}
	else
	{
		l_strBehaviorMessage += "authority not enough";
		l_pDeleteUserMessage_eNM_S2C_DELETE_USER_RESULT->iResultCode = eNetworkResultCode::eNRC_AUTHORITY_NOT_PERMIT;
		
	}
	MongoDBCURDDumpLogAndAddWaitForRespondNetworkMessage(l_pDeleteUserMessage_eNM_S2C_DELETE_USER_RESULT, l_strBehaviorMessage);
	return true;
}

bool cMongoDB::Process_eDB_CURD_UPDATE_USER_MACHINE(sCURD_UpdateUser_Machine*e_pCURD_Data, cUser*e_pConnectedUser)
{
	sUpdateUserDataInfo_eNM_C2S_UPDATE_USER_OWN_MACHINE_RESULT*l_pUpdateUserDataInfo_eNM_C2S_UPDATE_USER_OWN_MACHINE_RESULT = new sUpdateUserDataInfo_eNM_C2S_UPDATE_USER_OWN_MACHINE_RESULT();
	sprintf(l_pUpdateUserDataInfo_eNM_C2S_UPDATE_USER_OWN_MACHINE_RESULT->strID, "%s", e_pCURD_Data->strID.c_str());
	std::string l_strBehaviorMessage = UT::ComposeMsgByFormat("cMongoDB::Process_eDB_CURD_UPDATE_USER_MACHINE:%s %s %s machine %d",
		e_pCURD_Data->strID.c_str(), e_pCURD_Data->bAdd?"add":"delete", e_pCURD_Data->strTargetID.c_str(), e_pCURD_Data->iMachineID);

	auto l_UserData = e_pConnectedUser->GetUserData();
	//add a exists machine is not allow!
	int l_iMachineID = e_pCURD_Data->iMachineID;
	int l_iMachineIndex = l_UserData.GetMachineIndex(l_iMachineID);
	if (e_pCURD_Data->bAdd && l_iMachineIndex > -1)
	{
		l_strBehaviorMessage += "try to add a exists machine ";
		l_pUpdateUserDataInfo_eNM_C2S_UPDATE_USER_OWN_MACHINE_RESULT->iResultCode = eNRC_MACHINE_EXISTS;
	}
	else
	if (!e_pCURD_Data->bAdd && l_iMachineIndex == -1)
	{
		l_strBehaviorMessage += "try to delete a not exists machine";
		l_pUpdateUserDataInfo_eNM_C2S_UPDATE_USER_OWN_MACHINE_RESULT->iResultCode = eNRC_MACHINE_NOT_EXISTS;
	}
	else
	{
		try
		{
			std::string l_strMachineID = MACHINELIST;
			boost::optional<mongocxx::v_noabi::result::update> l_UpdateResult;
			auto l_Element = m_UserDataCollection.find_one(make_document(kvp(USER_ID, e_pCURD_Data->strTargetID.c_str())));
			if (!l_Element)
			{
				l_pUpdateUserDataInfo_eNM_C2S_UPDATE_USER_OWN_MACHINE_RESULT->iResultCode = eNRC_CURD_DB_FIND_ONE_ERROR;
				l_strBehaviorMessage += " find_one failed";
			}
			else
			{
				if (e_pCURD_Data->bAdd)
				{
					l_UpdateResult = this->m_UserDataCollection.update_one
					(
						make_document(kvp(USER_ID, e_pCURD_Data->strTargetID.c_str())),
						make_document(kvp("$push", make_document(kvp(l_strMachineID, l_iMachineID))))
					);
				}
				else
				{
					l_UpdateResult = this->m_UserDataCollection.update_one
					(
						make_document(kvp(USER_ID, e_pCURD_Data->strTargetID.c_str())),
						make_document(kvp("$pull", make_document(kvp(l_strMachineID, l_iMachineID))))
					);
				}
				const mongocxx::v_noabi::result::bulk_write l_Result = l_UpdateResult->result();
				sMongoDBUpdateResult l_sMongoDBUpdateResult(l_Result);
				if (l_sMongoDBUpdateResult.IsMatchedAndModifedSameCount(1))
				{
					l_pUpdateUserDataInfo_eNM_C2S_UPDATE_USER_OWN_MACHINE_RESULT->iResultCode = eNRC_OK;
					if (e_pCURD_Data->bAdd)
					{
						sMachineData l_MachineData;
						l_MachineData.iTWLeadStreamMachineNumber = l_iMachineID;
						l_UserData.OwnMachineVector.push_back(l_MachineData);
					}
					else
					{
						l_UserData.OwnMachineVector.erase(l_UserData.OwnMachineVector.begin() + l_iMachineIndex);
					}
				}
				else
				{
					l_pUpdateUserDataInfo_eNM_C2S_UPDATE_USER_OWN_MACHINE_RESULT->iResultCode = eNRC_CURD_DB_UPDATE_ERROR;
					l_strBehaviorMessage += "server data is not match DB,DB update_one failed!";
				}
			}
		}
		catch (std::exception e)
		{
			l_strBehaviorMessage += " DB exception";
			l_strBehaviorMessage += e.what();
			l_pUpdateUserDataInfo_eNM_C2S_UPDATE_USER_OWN_MACHINE_RESULT->iResultCode = eNRC_CURD_DB_EXCEPTION;
		}
	}
	MongoDBCURDDumpLogAndAddWaitForRespondNetworkMessage(l_pUpdateUserDataInfo_eNM_C2S_UPDATE_USER_OWN_MACHINE_RESULT, l_strBehaviorMessage);
	return true;
}

bool	GetReportCode(const char*e_strVersion,char*e_strReportCodeOutData, uint64 e_i64ExchangeIn, uint64 e_i64ExchangeOut, uint64 e_iBulletCount, int e_iReportCount, FISG_GAME_PARAMETERIZE::sTwLeadStreamProductData e_sTwLeadStreamProductData)
{
	if (!strcmp(e_strVersion, "1.3"))
	{
		FISG_GAME_PARAMETERIZE::GenerateReportCode_V_1_3(e_strReportCodeOutData,e_i64ExchangeIn,e_i64ExchangeOut,e_iBulletCount,e_iReportCount,e_sTwLeadStreamProductData);
		return true;
	}
	else
	if (!strcmp(e_strVersion, "1.4"))
	{
		FISG_GAME_PARAMETERIZE::GenerateReportCode_V_1_4(e_strReportCodeOutData, e_i64ExchangeIn, e_i64ExchangeOut, e_iBulletCount, e_iReportCount, e_sTwLeadStreamProductData);
		return true;
	}
	return false;
}

bsoncxx::document::value	GetReportInfoDocValue(sReportInfoWithReportCodes e_ReportInfoWithReportCodes, bsoncxx::builder::stream::document& e_Builder)
{
	bsoncxx::document::value doc_value =
		e_Builder
		<< CODE_REPORT_VERSION					<< e_ReportInfoWithReportCodes.strVersion.c_str()
		<< CODE_REPORT_REPORT_COUNT				<< e_ReportInfoWithReportCodes.iReportCount
		<< CODE_REPORT_PRODUCT_TYPE_NUMBER		<< e_ReportInfoWithReportCodes.iProductTypeNumber
		<< CODE_REPORT_MACHINE_ID				<< e_ReportInfoWithReportCodes.iMachineID
		<< CODE_REPORT_EXCHANGE_IN				<< e_ReportInfoWithReportCodes.i64ExchangeIn
		<< CODE_REPORT_EXCHANGE_OUT				<< e_ReportInfoWithReportCodes.i64ExchangeOut
		<< CODE_REPORT_BULLET_SHOOT_COUNT		<< e_ReportInfoWithReportCodes.i64BulletShootCount
		<< CODE_REPORT_BET_MONEY				<< e_ReportInfoWithReportCodes.i64BetMoney
		<< CODE_REPORT_WIN_MONEY				<< e_ReportInfoWithReportCodes.i64WinMoney
		<< CODE_REPORT_BULLET_TOTAL_SHOOT_COUNT	<< e_ReportInfoWithReportCodes.i64BulletTotalShootCount
		<< CODE_REPORT_OVER_COUNT				<< e_ReportInfoWithReportCodes.i64OVERCount
		<< CODE_REPORT_OVER_SCORE				<< e_ReportInfoWithReportCodes.i64OVERScore
		<< CODE_REPORT_GAME_WATER				<< e_ReportInfoWithReportCodes.i64GameWater
		<< bsoncxx::builder::stream::finalize;
	return doc_value;
}

bool cMongoDB::Process_eDB_CURD_ADD_REPORT_DATA(sCURD_AddReportData*e_pCURD_Data, cUser*e_pConnectedUser)
{
	sCodeReportResult_eNM_S2C_DO_CODE_REPORT_RESULT*l_pCodeReportResult_eNM_S2C_DO_CODE_REPORT_RESULT = new sCodeReportResult_eNM_S2C_DO_CODE_REPORT_RESULT();
	sprintf(l_pCodeReportResult_eNM_S2C_DO_CODE_REPORT_RESULT->strID, "%s", e_pCURD_Data->strID.c_str());
	auto l_UserData = e_pConnectedUser->GetUserData();
	std::string l_strBehaviorMessage = UT::ComposeMsgByFormat("Ver:%s,user ID:%s,machine ID %d,CodeVer%s,ExchangeIn:%zd,ExchangeOut:%zd,ReportCount:%d,ParameterCode:%s",
		e_pCURD_Data->strCodeReportVersion.c_str(),
		l_UserData.strID.c_str(),
		e_pCURD_Data->ReportInfo.iMachineID,
		e_pCURD_Data->strCodeReportVersion.c_str(),
		e_pCURD_Data->ReportInfo.i64ExchangeIn,
		e_pCURD_Data->ReportInfo.i64ExchangeOut,
		e_pCURD_Data->ReportInfo.iReportCount,
		e_pCURD_Data->strParameterCode);
	if (l_UserData.GetMachineIndex(e_pCURD_Data->ReportInfo.iMachineID) == -1)
	{
		sReportInfoWithReportCodes l_ReportInfoWithReportCodes = e_pCURD_Data->ReportInfo;
		l_ReportInfoWithReportCodes.strVersion = e_pCURD_Data->strCodeReportVersion.c_str();
		FISG_GAME_PARAMETERIZE::sTwLeadStreamProductData l_TwLeadStreamProductData;
		l_TwLeadStreamProductData.iMachineID = l_ReportInfoWithReportCodes.iMachineID;
		l_TwLeadStreamProductData.iProductTypeNumber = l_ReportInfoWithReportCodes.iProductTypeNumber;
		if (GetReportCode(e_pCURD_Data->strCodeReportVersion.c_str(),
			l_pCodeReportResult_eNM_S2C_DO_CODE_REPORT_RESULT->strReportCodeResult,
			l_ReportInfoWithReportCodes.i64ExchangeIn,
			l_ReportInfoWithReportCodes.i64ExchangeOut,
			l_ReportInfoWithReportCodes.i64BulletShootCount,
			l_ReportInfoWithReportCodes.iReportCount,
			l_TwLeadStreamProductData))
		{
			mongocxx::collection l_UserCollection = m_FishDatabase[e_pCURD_Data->strID.c_str()];
			if (!l_UserCollection)
			{//create a new collection.
				l_UserCollection = m_FishDatabase.create_collection(e_pCURD_Data->strID.c_str());
				l_strBehaviorMessage += UT::ComposeMsgByFormat(" try to add new collection %s ", e_pCURD_Data->strID.c_str());
			}
			try
			{
				auto l_Filter = document{} << MACHINE_ID << l_ReportInfoWithReportCodes.iMachineID << finalize;
				bsoncxx::stdx::optional<bsoncxx::document::value> l_UserDoc = l_UserCollection.find_one(l_Filter.view());
				bsoncxx::builder::stream::document l_Builder{};
				auto l_ReportInfoDocValue = GetReportInfoDocValue(l_ReportInfoWithReportCodes, l_Builder);
				if (!l_UserDoc)
				{//insert new document
					//insert document into array
					auto l_MachineDocumentValue = l_Builder
						<< MACHINE_ID << l_ReportInfoWithReportCodes.iMachineID
						<< MACHINE_REPORT_DATA_ARRAY << bsoncxx::builder::stream::open_array
						<< l_ReportInfoDocValue
						<< bsoncxx::builder::stream::close_array
						<< bsoncxx::builder::stream::finalize;
					auto l_InsertResult = l_UserCollection.insert_one(l_MachineDocumentValue.view());
					sMongoDBUpdateResult l_MongoDBUpdateResult(l_InsertResult->result());
					std::string l_strLog;
					if (l_MongoDBUpdateResult.inserted_count != 1)
					{
						l_pCodeReportResult_eNM_S2C_DO_CODE_REPORT_RESULT->iResultCode = eNRC_CURD_DB_INSERT_ERROR;
						l_strBehaviorMessage += " add new document failed";
					}
					else
					{
						l_strBehaviorMessage += " add new document ok";
						l_pCodeReportResult_eNM_S2C_DO_CODE_REPORT_RESULT->iResultCode = eNRC_OK;
					}
				}
				else
				{//update for insert report data into array
					auto l_UpdateResult = l_UserCollection.update_one
					(
						l_Filter.view(),
						make_document(kvp("$push", document{} << MACHINE_REPORT_DATA_ARRAY << l_ReportInfoDocValue << finalize))
					);
					sMongoDBUpdateResult l_MongoDBUpdateResult(l_UpdateResult->result());
					if (!l_MongoDBUpdateResult.IsMatchedAndModifedSameCount(1))
					{
						l_pCodeReportResult_eNM_S2C_DO_CODE_REPORT_RESULT->iResultCode = eNRC_CURD_DB_INSERT_ERROR;
						l_strBehaviorMessage += " add into array failed";
					}
					else
					{
						l_strBehaviorMessage += " add into array ok";
						l_pCodeReportResult_eNM_S2C_DO_CODE_REPORT_RESULT->iResultCode = eNRC_OK;
					}
				}
			}
			catch (std::exception e)
			{
				l_strBehaviorMessage += " DB exception! ";
				l_strBehaviorMessage += e.what();
				l_pCodeReportResult_eNM_S2C_DO_CODE_REPORT_RESULT->iResultCode = eNRC_CURD_DB_EXCEPTION;
			}
		}
		else
		{
			l_strBehaviorMessage += " version no match!";
			l_pCodeReportResult_eNM_S2C_DO_CODE_REPORT_RESULT->iResultCode = eNRC_REPORT_CODE_VERSION_NOT_MATCH;
		}
	}
	else
	{
		l_pCodeReportResult_eNM_S2C_DO_CODE_REPORT_RESULT->iResultCode = eNRC_MACHINE_NOT_EXISTS;
		l_strBehaviorMessage += " machine not exists";
	}
	MongoDBCURDDumpLogAndAddWaitForRespondNetworkMessage(l_pCodeReportResult_eNM_S2C_DO_CODE_REPORT_RESULT, l_strBehaviorMessage);
	return true;
}

cUser* cMongoDB::UserValidate(sCURD_DataBase*e_pCURD_DataBase)
{
	if (!e_pCURD_DataBase)
	{
		FMLog::LogWithFlag("Error cMongoDB::Process_DB_CURD e_pCURD_DataBase is nullptr", LOG_ID_MONGO_DB, true);
		return nullptr;
	}
	GET_USER_VECTOR_INSTANCE_AND_DO_MUTEX(l_pUserVector);
	auto l_pUser = l_pUserVector->GetObject(e_pCURD_DataBase->strID.c_str());
	auto l_pUserFromSocket = l_pUserVector->GetActivedConnectedUser(e_pCURD_DataBase->pClientSocket);
	if (!l_pUserFromSocket)
	{
		FMLog::LogWithFlag(UT::ComposeMsgByFormat("Error cMongoDB::UserValidate:user connection not exists:%s", e_pCURD_DataBase->strID.c_str()), LOG_ID_MONGO_DB, true);
		return nullptr;
	}
	if (l_pUser != l_pUserFromSocket)
	{
		FMLog::LogWithFlag(UT::ComposeMsgByFormat("Error cMongoDB::UserValidate:socket and user ID is not matched:%s", e_pCURD_DataBase->strID.c_str()), LOG_ID_MONGO_DB, true);
		return nullptr;
	}
	return l_pUser;
}
