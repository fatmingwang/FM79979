#include "stdafx.h"
#include "NetworkBrain.h"
#include "User.h"
#include "EventMessage.h"
#include  "SharedProtocal/NetworkMessage.h"

UT::sTimeCounter g_cTC;

cNetworkBrain::cNetworkBrain()
{
	//
	REG_EVENT(eEM_MONGODB_INITIALIZE_START, &cNetworkBrain::RefreshUserCollectionFromMongoDBStartEvent);
	REG_EVENT(eEM_MONGODB_INITIALIZE_FINISH, &cNetworkBrain::RefreshUserCollectionFromMongoDBFinishEvent);
	//
	//REG_NET_MESSAGE_FUNCTION(MESSAGE_ID, Function)
	this->SetClientLostConnectionCallback(std::bind(&cNetworkBrain::ClientLostConnection, this, std::placeholders::_1));
}

cNetworkBrain::~cNetworkBrain()
{
}

void cNetworkBrain::ClientLostConnection(_TCPsocket * e_pSocket)
{
	GET_USER_VECTOR_INSTANCE_AND_DO_MUTEX(l_pUserVector);
	l_pUserVector->RemoveActivedConnectedUser(e_pSocket);
}

bool	cNetworkBrain::RefreshUserCollectionFromMongoDBStartEvent(void*e_pData)
{
	this->Destroy();
	return true;
}

bool cNetworkBrain::RefreshUserCollectionFromMongoDBFinishEvent(void * e_pData)
{
	this->CreateAsServer(432, true);
	//cUserVector::GetInstance()->SetRefreshDataFromDB(true);
	return true;
}

void cNetworkBrain::Update(float e_fElpaseTime)
{
	cGameNetwork::Update(e_fElpaseTime);
	std::vector<sNetworkReceivedPacket*>l_DataVector = GetReceivedDataPleaseDeleteAfterUseIt();
	if (cGameApp::m_spMessageSenderManager)
	{
		size_t l_uiSize = l_DataVector.size();
		for (sNetworkReceivedPacket*l_pData : l_DataVector)
		{
			unsigned int l_uiID = *(unsigned int*)l_pData->pData;
			cGameApp::m_spMessageSenderManager->NetworkMessageShot(l_uiID, l_pData);
		}
	}
	DELETE_VECTOR(l_DataVector);
	std::vector<sBaseNetworkMessage*> l_VectorWaitForRespondNetworkMessageMutex;
	{
		MUTEX_PLACE_HOLDER(m_WaitForRespondNetworkMessageMutex);
		for (auto l_pData : m_WaitForRespondNetworkMessageVector)
		{
			l_VectorWaitForRespondNetworkMessageMutex.push_back(l_pData);
		}
		m_WaitForRespondNetworkMessageVector.clear();
	}
	{
		GET_USER_VECTOR_INSTANCE_AND_DO_MUTEX(l_pUserVector);
		for (auto l_pData : l_VectorWaitForRespondNetworkMessageMutex)
		{
			auto l_pActivedUser = l_pUserVector->GetObject(l_pData->strID);
			if (!l_pActivedUser->IsLogin())
			{//lost connection?
				FMLog::LogWithFlag(UT::ComposeMsgByFormat("Erro %s lost connection,send message failed", l_pActivedUser->GetName()), LOG_ID_NETWORK, true);
			}
			else
			{//send message
				SendMessageToClient(l_pActivedUser->GetSocket(), l_pData);
			}
			delete l_pData;
		}
		l_VectorWaitForRespondNetworkMessageMutex.clear();
	}
	
}

void cNetworkBrain::Destroy()
{
	cGameNetwork::Destroy();
	cUserVector::DestroyInstance();
}

extern cNetworkBrain*g_pNetworkBrain;
void			AddWaitForRespondNetworkMessage(struct sBaseNetworkMessage*e_pBaseNetworkMessage)
{
	if (g_pNetworkBrain)
	{
		g_pNetworkBrain->AddWaitForRespondNetworkMessage(e_pBaseNetworkMessage);
	}
}