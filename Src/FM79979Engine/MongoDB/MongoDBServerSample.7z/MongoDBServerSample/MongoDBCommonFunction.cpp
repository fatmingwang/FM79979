#include "stdafx.h"
#include "MongoDBCommonFunction.h"
#include "DBFieldName.h"

bool GetMongoDBElementValue(bsoncxx::v_noabi::document::element&e_Element, std::string& e_strOutValue, bsoncxx::v_noabi::type e_Type)
{
	if (e_Type == bsoncxx::v_noabi::type::k_utf8)
	{
		e_strOutValue = e_Element.get_utf8().value.to_string();
		return true;
	}
	return false;
}

bool GetMongoDBElementValue(bsoncxx::v_noabi::document::element&e_Element, int &e_iOutValue, bsoncxx::v_noabi::type e_Type)
{
	if (e_Type == bsoncxx::v_noabi::type::k_int32)
	{
		e_iOutValue = e_Element.get_int32().value;
		return true;
	}
	return false;
}

bool GetMongoDBElementValue(bsoncxx::v_noabi::document::element&e_Element, int64& e_iOutValue, bsoncxx::v_noabi::type e_Type)
{
	if (e_Type == bsoncxx::v_noabi::type::k_int64)
	{
		e_iOutValue = e_Element.get_int64().value;
		return true;
	}
	return false;
}
//============================================
template<class TYPE>
bool	GetElementValue(bsoncxx::v_noabi::document::view&e_View, const char*e_strFieldName, TYPE&e_OutValue, bool e_bWriteLogIfFailed)
{
	bsoncxx::v_noabi::document::element l_strElement = e_View[e_strFieldName];
	if (!l_strElement)
	{
		std::string l_str = "Error Field(element) not exists:";
		l_str += e_strFieldName;
		FMLog::LogWithFlag(l_str.c_str(), LOG_ID_MONGO_DB, true);
		return false;
	}
	bool l_bResult = false;
	//try
	//{
		auto l_Type = l_strElement.type();
		l_bResult = GetMongoDBElementValue(l_strElement, e_OutValue, l_Type);
		if (!l_bResult && e_bWriteLogIfFailed)
		{
			std::string l_str = "Error Field(element) type not match:";
			l_str += e_strFieldName;
			FMLog::LogWithFlag(l_str.c_str(), LOG_ID_MONGO_DB, true);
		}
	//}
	//catch (std::exception e)
	//{
	//	std::string l_str = "Field(element) ";
	//	l_str += e_strFieldName;
	//	l_str += " not exists:";
	//	FMLog::LogWithFlag(l_str.c_str(), LOG_ID_MONGO_DB, true);
	//}
	return l_bResult;
}

#define LAZY_GET_ELEMENT_FUNCTION(TYPE)	bool	GetElementValue(bsoncxx::v_noabi::document::view&e_View, const char*e_strFieldName,TYPE&e_OutValue, bool e_bWriteLogIfFailed)\
										{\
											return GetElementValue<TYPE>(e_View, e_strFieldName, e_OutValue, e_bWriteLogIfFailed);\
										}
LAZY_GET_ELEMENT_FUNCTION(std::string);
LAZY_GET_ELEMENT_FUNCTION(int);
LAZY_GET_ELEMENT_FUNCTION(int64);



bool GetMongoDBArrayIteratorValue(bsoncxx::v_noabi::array::view::const_iterator&e_Iterator, int &e_iOutValue, bsoncxx::v_noabi::type e_Type, bool e_bWriteLogIfFailed)
{
	if (e_Type == bsoncxx::v_noabi::type::k_int32)
	{
		e_iOutValue = e_Iterator->get_int32();
		return true;
	}
	return false;
}

bool GetMongoDBArrayIteratorValue(bsoncxx::v_noabi::array::view::const_iterator&e_Iterator, int64 &e_i64OutValue, bsoncxx::v_noabi::type e_Type, bool e_bWriteLogIfFailed)
{
	if (e_Type == bsoncxx::v_noabi::type::k_int64)
	{
		e_i64OutValue = e_Iterator->get_int64();
		return true;
	}
	return false;
}

bool GetMongoDBArrayIteratorValue(bsoncxx::v_noabi::array::view::const_iterator&e_Iterator, std::string &e_strOutValue, bsoncxx::v_noabi::type e_Type, bool e_bWriteLogIfFailed)
{
	if (e_Type == bsoncxx::v_noabi::type::k_utf8)
	{
		e_strOutValue = e_Iterator->get_utf8().value.to_string();
		return true;
	}
	return false;
}

bool GetMongoDBArrayIteratorValue(bsoncxx::v_noabi::array::view::const_iterator&e_Iterator, sReportInfoWithReportCodes&e_ReportInfo, bsoncxx::v_noabi::type e_Type, bool e_bWriteLogIfFailed)
{
	if (e_Type == bsoncxx::v_noabi::type::k_document)
	{
		auto l_View = e_Iterator->get_document().view();
		if (!GetElementValue(l_View, CODE_REPORT_REPORT_COUNT, e_ReportInfo.iReportCount) ||
			!GetElementValue(l_View, CODE_REPORT_PRODUCT_TYPE_NUMBER, e_ReportInfo.iProductTypeNumber) ||
			!GetElementValue(l_View, CODE_REPORT_MACHINE_ID, e_ReportInfo.iMachineID) ||
			!GetElementValue(l_View, CODE_REPORT_EXCHANGE_IN, e_ReportInfo.i64ExchangeIn) ||
			!GetElementValue(l_View, CODE_REPORT_EXCHANGE_OUT, e_ReportInfo.i64ExchangeOut) ||
			!GetElementValue(l_View, CODE_REPORT_BULLET_SHOOT_COUNT, e_ReportInfo.i64BulletShootCount) ||
			!GetElementValue(l_View, CODE_REPORT_BET_MONEY, e_ReportInfo.i64BetMoney) ||
			!GetElementValue(l_View, CODE_REPORT_WIN_MONEY, e_ReportInfo.i64WinMoney) ||
			!GetElementValue(l_View, CODE_REPORT_BULLET_TOTAL_SHOOT_COUNT, e_ReportInfo.i64BulletTotalShootCount) ||
			!GetElementValue(l_View, CODE_REPORT_OVER_COUNT, e_ReportInfo.i64OVERCount) ||
			!GetElementValue(l_View, CODE_REPORT_OVER_SCORE, e_ReportInfo.i64OVERScore) ||
			!GetElementValue(l_View, CODE_REPORT_GAME_WATER, e_ReportInfo.i64GameWater))
		{
			std::string l_str = "Error GetMongoDBArrayIteratorValue one of sReportInfoWithReportCodes data type is not match";
			FMLog::LogWithFlag(l_str.c_str(), LOG_ID_MONGO_DB, true);
			return false;
		}
	}
	else
	{
		std::string l_str = "Error GetMongoDBArrayIteratorValue type is not document(sReportInfoWithReportCodes):";
		FMLog::LogWithFlag(l_str.c_str(), LOG_ID_MONGO_DB, true);
	}
	return true;
}


template<class TYPE>
bool	GetMongonDBArrayValue(bsoncxx::v_noabi::document::view & e_View, const char * e_strFieldName, std::vector<TYPE>& e_OutValueVector, bool e_bWriteLogIfFailed)
{
	bsoncxx::v_noabi::document::element	l_Element = e_View[e_strFieldName];
	if (!l_Element)
	{
		std::string l_str = "Error Field(element) not exists:";
		l_str += e_strFieldName;
		FMLog::LogWithFlag(l_str.c_str(), LOG_ID_MONGO_DB, true);
		return false;
	}
	bool l_bResult = true;
	//try
	//{
		auto l_Type = l_Element.type();
		if (l_Type != bsoncxx::v_noabi::type::k_array)
		{
			std::string l_str = "Error Field(element) type not match:";
			l_str += e_strFieldName;
			FMLog::LogWithFlag(l_str.c_str(), LOG_ID_MONGO_DB, true);
			return false;
		}
		bsoncxx::v_noabi::types::b_array l_Array = l_Element.get_array();
		bsoncxx::v_noabi::array::view l_ArrayView = l_Array.value;
		int l_iIndex = 0;
		for (auto l_Iterator = l_ArrayView.cbegin(); l_Iterator != l_ArrayView.cend(); ++l_Iterator)
		{
			TYPE l_Value;
			if (GetMongoDBArrayIteratorValue(l_Iterator, l_Value, l_Iterator->type(), true))
			{
				e_OutValueVector.push_back(l_Value);
			}
			else
			{
				std::string l_str = "Error ";
				l_str += e_strFieldName;
				l_str += ":array iterator type not match Index:";
				l_str += ValueToString(l_iIndex);
				l_str += " type is:";
				l_str += ValueToString((int)l_Iterator->type());
				FMLog::LogWithFlag(l_str, LOG_ID_MONGO_DB, true);
				l_bResult = false;
			}
			++l_iIndex;
		}
	//}
	//catch (std::exception e)
	//{
	//	l_bResult = false;
	//	std::string l_str = "Array(element) ";
	//	l_str += e_strFieldName;
	//	l_str += " not exists:";
	//	l_str += e.what();
	//	FMLog::LogWithFlag(l_str.c_str(), LOG_ID_MONGO_DB, true);
	//}
	return l_bResult;
}

//
#define LAZY_GET_ARRAY_VALUE_FUNCTION(TYPE)	bool	GetArrayValue(bsoncxx::v_noabi::document::view & e_View, const char * e_strFieldName, std::vector<TYPE>& e_OutValueVector, bool e_bWriteLogIfFailed)\
										{\
											return GetMongonDBArrayValue<TYPE>(e_View,e_strFieldName,e_OutValueVector,e_bWriteLogIfFailed);\
										}
LAZY_GET_ARRAY_VALUE_FUNCTION(std::string);
LAZY_GET_ARRAY_VALUE_FUNCTION(int);
LAZY_GET_ARRAY_VALUE_FUNCTION(int64);
LAZY_GET_ARRAY_VALUE_FUNCTION(sReportInfoWithReportCodes);