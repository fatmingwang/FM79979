#include "stdafx.h"
#include "User.h"
#include "NetworkBrain.h"
#include  "SharedProtocal/NetworkMessage.h"
#include "EventMessage.h"
#include "User.h"
#include "MongoDB.h"
#if defined(WIN32)
#pragma warning( disable : 4996 )
#endif
void	NetworkMessageProcessDumpLogAndAddQueryDataIntoDBQueryVector(sCURD_DataBase*e_CURD_DataBase, std::string&e_strBehaviorMessage)
{
	std::string l_strLog = UT::ComposeMsgByFormat("CURD type:%d,", e_CURD_DataBase->DBcurdType);
	l_strLog += e_strBehaviorMessage;
	FMLog::LogWithFlag(l_strLog.c_str(), LOG_ID_NETWORK, true);
	AddQueryDataIntoDBQueryVector(e_CURD_DataBase);
}

bool cNetworkBrain::SendMessageToClient(FATMING_CORE::sNetworkReceivedPacket*e_pNetworkReceivedPacket, sBaseNetworkMessage*e_pBaseNetworkMessage)
{
	return SendMessageToClient(e_pNetworkReceivedPacket->pReceivedSocket, e_pBaseNetworkMessage);
}

bool cNetworkBrain::SendMessageToClient(_TCPsocket * e_pTCPsocket, sBaseNetworkMessage * e_pBaseNetworkMessage)
{
	sNetworkSendPacket l_sNetworkSendPacket;
	l_sNetworkSendPacket.iSize = e_pBaseNetworkMessage->Size();
	l_sNetworkSendPacket.pData = (char*)e_pBaseNetworkMessage;
	l_sNetworkSendPacket.pData = (char*)e_pBaseNetworkMessage;
	bool	l_bResult = false;
	if (SendData(e_pTCPsocket, &l_sNetworkSendPacket))
	{
		UT::ComposeMsgByFormat("Ok send MessageID:%d", e_pBaseNetworkMessage->iMessage);
		l_bResult = true;
	}
	else
	{
		UT::ComposeMsgByFormat("Error send MessageID:%d", e_pBaseNetworkMessage->iMessage);
		l_bResult = false;
	}
	l_sNetworkSendPacket.pData = nullptr;
	return l_bResult;
}

void cNetworkBrain::AddWaitForRespondNetworkMessage(struct sBaseNetworkMessage*e_pBaseNetworkMessage)
{
	MUTEX_PLACE_HOLDER(m_WaitForRespondNetworkMessageMutex);
	if (this->GetNetWorkStatus() != eNWS_CONNECTED)
	{
		UT::ComposeMsgByFormat("lost connection and try to send message:%d", e_pBaseNetworkMessage->iMessage);
		return;
	}
	m_WaitForRespondNetworkMessageVector.push_back(e_pBaseNetworkMessage);

}

bool cNetworkBrain::NetworkMessage_eNM_C2S_LOGIN_REQUEST(FATMING_CORE::sNetworkReceivedPacket*e_pNetworkReceivedPacket)
{
	sLoginResultMessage_eNM_S2C_LOGIN_RESULT l_sLoginResultMessage_eNM_S2C_LOGIN_RESULT;
	l_sLoginResultMessage_eNM_S2C_LOGIN_RESULT.iResultCode = sLoginResultMessage_eNM_S2C_LOGIN_RESULT::eR_NO_USER;//no such 
	sLoginMessage_eNM_C2S_LOGIN_REQUEST*l_pLoginMessage_eNM_C2S_LOGIN_REQUEST = (sLoginMessage_eNM_C2S_LOGIN_REQUEST*)e_pNetworkReceivedPacket->pData;
	GET_USER_VECTOR_INSTANCE_AND_DO_MUTEX(l_pUserVector);
	auto l_pUser = l_pUserVector->GetObject(l_pLoginMessage_eNM_C2S_LOGIN_REQUEST->strID);
	if (l_pUser)
	{		
		float l_fVersion = l_pLoginMessage_eNM_C2S_LOGIN_REQUEST->fVersion;
		auto l_UserData = l_pUser->GetUserData();
		if (l_UserData.ComparePassword(l_pLoginMessage_eNM_C2S_LOGIN_REQUEST->strPwd))
		{
			l_sLoginResultMessage_eNM_S2C_LOGIN_RESULT.iUserAuthority = (int)l_UserData.m_eUserAuthority;
			memset(l_sLoginResultMessage_eNM_S2C_LOGIN_RESULT.iMachineIDArray, 0, sizeof(l_sLoginResultMessage_eNM_S2C_LOGIN_RESULT.iMachineIDArray));
			for (auto i = 0; i < l_UserData.OwnMachineVector.size(); ++i)
			{
				l_sLoginResultMessage_eNM_S2C_LOGIN_RESULT.iMachineIDArray[i] = l_UserData.OwnMachineVector[i].iTWLeadStreamMachineNumber;
			}
			l_sLoginResultMessage_eNM_S2C_LOGIN_RESULT.iResultCode = sLoginResultMessage_eNM_S2C_LOGIN_RESULT::eR_LOGIN_OK;
			l_pUserVector->AddActivedConnectedUser(e_pNetworkReceivedPacket->pReceivedSocket, l_pLoginMessage_eNM_C2S_LOGIN_REQUEST->strID);
		}
		else
		{
			l_sLoginResultMessage_eNM_S2C_LOGIN_RESULT.iResultCode = sLoginResultMessage_eNM_S2C_LOGIN_RESULT::eR_PWD_ERROR;
		}
	}
	std::string l_strBehaviorMessage = UT::ComposeMsgByFormat
	(	"app version:%f ID:%s PWD:%s,Result %s",
		l_pLoginMessage_eNM_C2S_LOGIN_REQUEST->fVersion,
		l_pLoginMessage_eNM_C2S_LOGIN_REQUEST->strPwd,
		l_pLoginMessage_eNM_C2S_LOGIN_REQUEST->strID,
		l_sLoginResultMessage_eNM_S2C_LOGIN_RESULT.GetResultString((sLoginResultMessage_eNM_S2C_LOGIN_RESULT::eResult)l_sLoginResultMessage_eNM_S2C_LOGIN_RESULT.iResultCode)
	);
	std::string l_strLog = UT::ComposeMsgByFormat("%s cNetworkBrain::NetworkMessage_eNM_C2S_LOGIN_REQUEST %s", 
		l_sLoginResultMessage_eNM_S2C_LOGIN_RESULT.iResultCode== sLoginResultMessage_eNM_S2C_LOGIN_RESULT::eR_LOGIN_OK?"Ok":"Error",
		l_strBehaviorMessage.c_str());
	FMLog::LogWithFlag(l_strLog.c_str(), LOG_ID_NETWORK, true);
	SendMessageToClient(e_pNetworkReceivedPacket, &l_sLoginResultMessage_eNM_S2C_LOGIN_RESULT);
	return true;
}

bool cNetworkBrain::NetworkMessage_eNM_C2S_ADD_USER_REQUEST(FATMING_CORE::sNetworkReceivedPacket * e_pNetworkReceivedPacket)
{
	sAddUserMessage_eNM_C2S_ADD_USER_REQUEST*l_pAddUserMessage_eNM_C2S_ADD_USER_REQUEST = (sAddUserMessage_eNM_C2S_ADD_USER_REQUEST*)e_pNetworkReceivedPacket->pData;
	std::string l_strBehaviorMessage = UT::ComposeMsgByFormat("cNetworkBrain::NetworkMessage_eNM_C2S_ADD_USER_REQUEST %s want to create %s", 
		l_pAddUserMessage_eNM_C2S_ADD_USER_REQUEST->strID,
		l_pAddUserMessage_eNM_C2S_ADD_USER_REQUEST->strTargetID);
	if (!AdminAuthorityAndTargetUserCheck(l_pAddUserMessage_eNM_C2S_ADD_USER_REQUEST->strID, l_pAddUserMessage_eNM_C2S_ADD_USER_REQUEST->strTargetID, e_pNetworkReceivedPacket, "cNetworkBrain::NetworkMessage_eNM_C2S_ADD_USER_REQUEST "))
		return false;
	sCURD_CreateUser* l_pCURD_CreateUser = new sCURD_CreateUser();
	l_pCURD_CreateUser->DBcurdType = eDB_CURD_Type::eDB_CURD_CREATE_USER;
	l_pCURD_CreateUser->strCreateID = l_pAddUserMessage_eNM_C2S_ADD_USER_REQUEST->strTargetID;
	l_pCURD_CreateUser->strDescription = l_pAddUserMessage_eNM_C2S_ADD_USER_REQUEST->strDescription;
	l_pCURD_CreateUser->strPWD = l_pAddUserMessage_eNM_C2S_ADD_USER_REQUEST->strPwd;
	std::string l_strLog = "Ok:";
	l_strLog += l_strBehaviorMessage;
	FMLog::LogWithFlag(l_strLog.c_str(), LOG_ID_NETWORK, true);
	AddQueryDataIntoDBQueryVector(l_pCURD_CreateUser);
	return true;
}

bool cNetworkBrain::NetworkMessage_eNM_C2S_DELETE_USER_REQUEST(FATMING_CORE::sNetworkReceivedPacket * e_pNetworkReceivedPacket)
{
	sDeleteUserMessage_eNM_C2S_DELETE_USER_REQUEST*l_pDeleteUserMessage_eNM_C2S_DELETE_USER_REQUEST = (sDeleteUserMessage_eNM_C2S_DELETE_USER_REQUEST*)e_pNetworkReceivedPacket->pData;
	std::string l_strBehaviorMessage = UT::ComposeMsgByFormat("cNetworkBrain::NetworkMessage_eNM_C2S_DELETE_USER_REQUEST %s want to delete %s",
		l_pDeleteUserMessage_eNM_C2S_DELETE_USER_REQUEST->strID,
		l_pDeleteUserMessage_eNM_C2S_DELETE_USER_REQUEST->strTargetID);
	if (!AdminAuthorityAndTargetUserCheck(l_pDeleteUserMessage_eNM_C2S_DELETE_USER_REQUEST->strID, l_pDeleteUserMessage_eNM_C2S_DELETE_USER_REQUEST->strTargetID, e_pNetworkReceivedPacket,"cNetworkBrain::NetworkMessage_eNM_C2S_DELETE_USER_REQUEST "))
		return false;
	sCURD_UpdateUser*l_pCURD_UpdateUser = new sCURD_UpdateUser();
	l_pCURD_UpdateUser->DBcurdType = eDB_CURD_Type::eDB_CURD_DELETE_USER;
	l_pCURD_UpdateUser->strID = l_pDeleteUserMessage_eNM_C2S_DELETE_USER_REQUEST->strID;
	l_pCURD_UpdateUser->strPWD = l_pDeleteUserMessage_eNM_C2S_DELETE_USER_REQUEST->strPwd;
	std::string l_strLog = "Ok:";
	l_strLog += l_strBehaviorMessage;
	FMLog::LogWithFlag(l_strLog.c_str(), LOG_ID_NETWORK, true);
	AddQueryDataIntoDBQueryVector(l_pCURD_UpdateUser);
	return true;
}

bool cNetworkBrain::NetworkMessage_eNM_C2S_UPDATE_USER_REQUEST(FATMING_CORE::sNetworkReceivedPacket * e_pNetworkReceivedPacket)
{
	sUpdateUserDataInfo_eNM_C2S_UPDATE_USER_REQUEST*l_pUpdateUserDataInfo_eNM_C2S_UPDATE_USER_REQUEST = (sUpdateUserDataInfo_eNM_C2S_UPDATE_USER_REQUEST*)e_pNetworkReceivedPacket->pData;;
	std::string l_strBehaviorMessage = UT::ComposeMsgByFormat(
		"cNetworkBrain::NetworkMessage_eNM_C2S_DELETE_USER_REQUEST %s want to update user %s info,old PWD %s new PWD %s ,Description:%s",
		l_pUpdateUserDataInfo_eNM_C2S_UPDATE_USER_REQUEST->strID,
		l_pUpdateUserDataInfo_eNM_C2S_UPDATE_USER_REQUEST->strTargetID,
		l_pUpdateUserDataInfo_eNM_C2S_UPDATE_USER_REQUEST->strPWD,
		l_pUpdateUserDataInfo_eNM_C2S_UPDATE_USER_REQUEST->strNewPWD,
		l_pUpdateUserDataInfo_eNM_C2S_UPDATE_USER_REQUEST->strDescription);
	if (!AdminAuthorityAndTargetUserCheck(l_pUpdateUserDataInfo_eNM_C2S_UPDATE_USER_REQUEST->strID, l_pUpdateUserDataInfo_eNM_C2S_UPDATE_USER_REQUEST->strTargetID, e_pNetworkReceivedPacket, "cNetworkBrain::NetworkMessage_eNM_C2S_UPDATE_USER_REQUEST"))
		return false;
	sCURD_UpdateUser*l_pCURD_UpdateUser = new sCURD_UpdateUser();
	l_pCURD_UpdateUser->DBcurdType = eDB_CURD_UPDATE_USER;
	l_pCURD_UpdateUser->strDescription = l_pUpdateUserDataInfo_eNM_C2S_UPDATE_USER_REQUEST->strDescription;
	l_pCURD_UpdateUser->strID = l_pUpdateUserDataInfo_eNM_C2S_UPDATE_USER_REQUEST->strID;
	l_pCURD_UpdateUser->strNewPWD = l_pUpdateUserDataInfo_eNM_C2S_UPDATE_USER_REQUEST->strNewPWD;
	l_pCURD_UpdateUser->strPWD = l_pUpdateUserDataInfo_eNM_C2S_UPDATE_USER_REQUEST->strPWD;
	NetworkMessageProcessDumpLogAndAddQueryDataIntoDBQueryVector(l_pCURD_UpdateUser, l_strBehaviorMessage);
	return true;
}

bool cNetworkBrain::NetworkMessage_eNM_C2S_UPDATE_USER_OWN_MACHINE_REQUEST(FATMING_CORE::sNetworkReceivedPacket * e_pNetworkReceivedPacket)
{
	sUpdateUserOwnMachine_eNM_C2S_UPDATE_USER_OWN_MACHINE_REQUEST*l_pUpdateUserOwnMachine_eNM_C2S_UPDATE_USER_OWN_MACHINE_REQUEST = (sUpdateUserOwnMachine_eNM_C2S_UPDATE_USER_OWN_MACHINE_REQUEST*)e_pNetworkReceivedPacket->pData;
	std::string l_strBehaviorMessage = UT::ComposeMsgByFormat("cNetworkBrain::NetworkMessage_eNM_C2S_UPDATE_USER_OWN_MACHINE_REQUEST:%s want %s %s Machine:%d",
		l_pUpdateUserOwnMachine_eNM_C2S_UPDATE_USER_OWN_MACHINE_REQUEST->strID,
		l_pUpdateUserOwnMachine_eNM_C2S_UPDATE_USER_OWN_MACHINE_REQUEST->strTargetID,
		l_pUpdateUserOwnMachine_eNM_C2S_UPDATE_USER_OWN_MACHINE_REQUEST->bAddNewMachine?"add":"delete",
		l_pUpdateUserOwnMachine_eNM_C2S_UPDATE_USER_OWN_MACHINE_REQUEST->iMachineID);
	if (!AdminAuthorityAndTargetUserCheck(l_pUpdateUserOwnMachine_eNM_C2S_UPDATE_USER_OWN_MACHINE_REQUEST->strID,
		l_pUpdateUserOwnMachine_eNM_C2S_UPDATE_USER_OWN_MACHINE_REQUEST->strTargetID,
		e_pNetworkReceivedPacket, l_strBehaviorMessage.c_str()))
		return false;
	sCURD_UpdateUser_Machine*l_pCURD_UpdateUser_Machine = new sCURD_UpdateUser_Machine();
	l_pCURD_UpdateUser_Machine->DBcurdType = eDB_CURD_UPDATE_USER_MACHINE;
	l_pCURD_UpdateUser_Machine->iMachineID = l_pUpdateUserOwnMachine_eNM_C2S_UPDATE_USER_OWN_MACHINE_REQUEST->iMachineID;
	l_pCURD_UpdateUser_Machine->strID = l_pUpdateUserOwnMachine_eNM_C2S_UPDATE_USER_OWN_MACHINE_REQUEST->strID;
	l_pCURD_UpdateUser_Machine->strTargetID = l_pUpdateUserOwnMachine_eNM_C2S_UPDATE_USER_OWN_MACHINE_REQUEST->strTargetID;
	NetworkMessageProcessDumpLogAndAddQueryDataIntoDBQueryVector(l_pCURD_UpdateUser_Machine, l_strBehaviorMessage);
	return true;
}

bool cNetworkBrain::NetworkMessage_eNM_C2S_DO_CODE_REPORT_REQUEST(FATMING_CORE::sNetworkReceivedPacket * e_pNetworkReceivedPacket)
{
	sCodeReportRequest_eNM_C2S_DO_CODE_REPORT_REQUEST*l_pCodeReportRequest_eNM_C2S_DO_CODE_REPORT_REQUEST = (sCodeReportRequest_eNM_C2S_DO_CODE_REPORT_REQUEST*)e_pNetworkReceivedPacket->pData;
	std::string l_strBehaviorMessage = UT::ComposeMsgByFormat(
		"cNetworkBrain::NetworkMessage_eNM_C2S_DO_CODE_REPORT_REQUEST:%s request a code report,BulletCount:%zd,ExchangeIn:%zd,ExchangeOut:%zd,ReportCount:%d,ReportCodeVersion:%s,ParameterCodes",
		l_pCodeReportRequest_eNM_C2S_DO_CODE_REPORT_REQUEST->strID,
		l_pCodeReportRequest_eNM_C2S_DO_CODE_REPORT_REQUEST->i64BulletCount,
		l_pCodeReportRequest_eNM_C2S_DO_CODE_REPORT_REQUEST->i64ExchangeIn,
		l_pCodeReportRequest_eNM_C2S_DO_CODE_REPORT_REQUEST->i64ExchangeOut,
		l_pCodeReportRequest_eNM_C2S_DO_CODE_REPORT_REQUEST->iReportCount,
		l_pCodeReportRequest_eNM_C2S_DO_CODE_REPORT_REQUEST->ReportCodeVersion,
		l_pCodeReportRequest_eNM_C2S_DO_CODE_REPORT_REQUEST->ParameterCode);
	GET_USER_VECTOR_INSTANCE_AND_DO_MUTEX(l_pUserVector);
	auto l_pSocketUser = l_pUserVector->GetActivedConnectedUser(e_pNetworkReceivedPacket->pReceivedSocket);
	auto l_pIDUser = l_pUserVector->GetObject(l_pCodeReportRequest_eNM_C2S_DO_CODE_REPORT_REQUEST->strID);
	if (l_pSocketUser != l_pIDUser)
	{
		std::string l_strLog = "Error:";
		l_strBehaviorMessage += "socket and ID is not match:";
		l_strLog += l_strBehaviorMessage;
		FMLog::LogWithFlag(l_strLog.c_str(), LOG_ID_NETWORK, true);
		sCodeReportResult_eNM_S2C_DO_CODE_REPORT_RESULT l_CodeReportResult_eNM_S2C_DO_CODE_REPORT_RESULT;
		sprintf(l_CodeReportResult_eNM_S2C_DO_CODE_REPORT_RESULT.strID,"%s", l_pCodeReportRequest_eNM_C2S_DO_CODE_REPORT_REQUEST->strID);
		l_CodeReportResult_eNM_S2C_DO_CODE_REPORT_RESULT.iResultCode = eNRC_REPORT_CODE_SOCKET_AND_ID_NOT_MATCH;
		SendMessageToClient(e_pNetworkReceivedPacket->pReceivedSocket,&l_CodeReportResult_eNM_S2C_DO_CODE_REPORT_RESULT);
		return false;
	}
	sCURD_AddReportData*l_pCURD_AddReportData = new sCURD_AddReportData();
	l_pCURD_AddReportData->DBcurdType = eDB_CURD_ADD_REPORT_DATA;
	l_pCURD_AddReportData->ReportInfo.i64ExchangeIn = l_pCodeReportRequest_eNM_C2S_DO_CODE_REPORT_REQUEST->i64ExchangeIn;
	l_pCURD_AddReportData->ReportInfo.i64ExchangeOut = l_pCodeReportRequest_eNM_C2S_DO_CODE_REPORT_REQUEST->i64ExchangeOut;
	l_pCURD_AddReportData->ReportInfo.iReportCount = l_pCodeReportRequest_eNM_C2S_DO_CODE_REPORT_REQUEST->iReportCount;
	l_pCURD_AddReportData->ReportInfo.i64BulletShootCount = l_pCodeReportRequest_eNM_C2S_DO_CODE_REPORT_REQUEST->i64BulletCount;
	l_pCURD_AddReportData->strCodeReportVersion = l_pCodeReportRequest_eNM_C2S_DO_CODE_REPORT_REQUEST->ReportCodeVersion;
	memcpy(l_pCURD_AddReportData->strParameterCode, l_pCodeReportRequest_eNM_C2S_DO_CODE_REPORT_REQUEST->ParameterCode, sizeof(l_pCURD_AddReportData->strParameterCode));
	NetworkMessageProcessDumpLogAndAddQueryDataIntoDBQueryVector(l_pCURD_AddReportData, l_strBehaviorMessage);
	return true;
}

sQueryUserMachineHistory_eNM_S2C_QUERY_MACHINE_HISTORY_RESULT::sNetworkworkReportInfoWithReportCodes ConvertReportInfoWithReportCodes(sReportInfoWithReportCodes&e_ReportInfoWithReportCodes)
{
	sQueryUserMachineHistory_eNM_S2C_QUERY_MACHINE_HISTORY_RESULT::sNetworkworkReportInfoWithReportCodes l_Struct;
	l_Struct.i64BetMoney = e_ReportInfoWithReportCodes.i64BetMoney;
	l_Struct.i64BulletShootCount = e_ReportInfoWithReportCodes.i64BulletShootCount;
	l_Struct.i64BulletTotalShootCount = e_ReportInfoWithReportCodes.i64BulletTotalShootCount;
	l_Struct.i64ExchangeIn = e_ReportInfoWithReportCodes.i64ExchangeIn;
	l_Struct.i64ExchangeOut = e_ReportInfoWithReportCodes.i64ExchangeOut;
	l_Struct.i64GameWater = e_ReportInfoWithReportCodes.i64GameWater;
	l_Struct.i64OVERCount = e_ReportInfoWithReportCodes.i64OVERCount;
	l_Struct.i64OVERCount = e_ReportInfoWithReportCodes.i64OVERScore;
	l_Struct.i64WinMoney = e_ReportInfoWithReportCodes.i64WinMoney;
	l_Struct.iMachineID = e_ReportInfoWithReportCodes.iMachineID;
	l_Struct.iProductTypeNumber = e_ReportInfoWithReportCodes.iProductTypeNumber;
	l_Struct.iReportCount = e_ReportInfoWithReportCodes.iReportCount;
	memcpy(l_Struct.strReportCode, e_ReportInfoWithReportCodes.strReportCode, sizeof(char) * 50);
	//e_ReportInfoWithReportCodes.strVersion;
	return l_Struct;
}
bool cNetworkBrain::NetworkMessage_eNM_C2S_QUERY_MACHINE_HISTORY_REQUEST(FATMING_CORE::sNetworkReceivedPacket * e_pNetworkReceivedPacket)
{
	sQueryUserMachineHistory_eNM_C2S_QUERY_MACHINE_HISTORY_REQUEST*l_pUpdateUserOwnMachine_eNM_C2S_UPDATE_USER_OWN_MACHINE_REQUEST = (sQueryUserMachineHistory_eNM_C2S_QUERY_MACHINE_HISTORY_REQUEST*)e_pNetworkReceivedPacket->pData;
	std::string l_strBehaviorMessage = UT::ComposeMsgByFormat(
		"cNetworkBrain::NetworkMessage_eNM_C2S_QUERY_MACHINE_HISTORY_REQUEST:%s query machine %d history,",
		l_pUpdateUserOwnMachine_eNM_C2S_UPDATE_USER_OWN_MACHINE_REQUEST->strID,
		l_pUpdateUserOwnMachine_eNM_C2S_UPDATE_USER_OWN_MACHINE_REQUEST->iMachineID);
	l_pUpdateUserOwnMachine_eNM_C2S_UPDATE_USER_OWN_MACHINE_REQUEST->iMachineID;
	GET_USER_VECTOR_INSTANCE_AND_DO_MUTEX(l_pUserVector);
	bool	l_bResult = true;
	auto l_pUser = l_pUserVector->GetActivedConnectedUser(e_pNetworkReceivedPacket->pReceivedSocket);
	if (l_pUser)
	{
		cUser*l_pTargetUser = l_pUserVector->GetObject(l_pUpdateUserOwnMachine_eNM_C2S_UPDATE_USER_OWN_MACHINE_REQUEST->strID);
		if (!l_pTargetUser)
		{
			l_bResult = false;
			l_strBehaviorMessage += " targetUser is not exists,";
		}
		else
		if (l_pTargetUser != l_pUser && l_pTargetUser->GetUserData().m_eUserAuthority != eUA_ADMIN)
		{
			l_bResult = false;
			l_strBehaviorMessage += " user authority is not enough,";
		}
		else
		{
			sQueryUserMachineHistory_eNM_S2C_QUERY_MACHINE_HISTORY_RESULT l_QueryUserMachineHistory_eNM_S2C_QUERY_MACHINE_HISTORY_RESULT;
			l_QueryUserMachineHistory_eNM_S2C_QUERY_MACHINE_HISTORY_RESULT.iResultCode = 1;
			auto l_UserData = l_pTargetUser->GetUserData();
			auto l_Iterator = l_UserData.m_MachineIDAndReportInfoMap.find(l_pUpdateUserOwnMachine_eNM_C2S_UPDATE_USER_OWN_MACHINE_REQUEST->iMachineID);
			if (l_Iterator != l_UserData.m_MachineIDAndReportInfoMap.end())
			{
				auto l_ReportInfoVector = l_Iterator->second;
				int l_iNumToGo = (int)l_ReportInfoVector.size()/ MACHINE_REPORT_INFO_REQUEST_HISTORY_COUNT +1;
				for (int i=0;i< l_iNumToGo;++i)
				{
					int l_iStartIndex = i * MACHINE_REPORT_INFO_REQUEST_HISTORY_COUNT;
					l_QueryUserMachineHistory_eNM_S2C_QUERY_MACHINE_HISTORY_RESULT.iRecordStartIndex = l_iStartIndex;
					l_QueryUserMachineHistory_eNM_S2C_QUERY_MACHINE_HISTORY_RESULT.iRecordCount = (int)l_ReportInfoVector.size()- l_iStartIndex;
					l_QueryUserMachineHistory_eNM_S2C_QUERY_MACHINE_HISTORY_RESULT.bNextDataExists = 
						l_iStartIndex+ MACHINE_REPORT_INFO_REQUEST_HISTORY_COUNT>= l_ReportInfoVector.size()?false:true;
					for (int j = 0; i < MACHINE_REPORT_INFO_REQUEST_HISTORY_COUNT; ++j)
					{
						l_QueryUserMachineHistory_eNM_S2C_QUERY_MACHINE_HISTORY_RESULT.ReportInfoArray[j] = ConvertReportInfoWithReportCodes(l_ReportInfoVector[l_iStartIndex + j]);
					}
					//same thread don't need to push into m_WaitForRespondNetworkMessageVector
					if (SendMessageToClient(e_pNetworkReceivedPacket, &l_QueryUserMachineHistory_eNM_S2C_QUERY_MACHINE_HISTORY_RESULT))
					{
						l_strBehaviorMessage += UT::ComposeMsgByFormat("%d of %d Messages sent okay,", i, l_iNumToGo);
					}
					else
					{
						l_strBehaviorMessage += UT::ComposeMsgByFormat("%d of %d Messages sent failed,", i, l_iNumToGo);
						l_bResult = false;
					}
				}
			}
			else
			{
				l_strBehaviorMessage += "such machineID is not exist,";
				l_bResult = false;
			}
		}
	}
	else
	{
		l_strBehaviorMessage += "socket cannt find ActivedUser";
		l_bResult = false;
	}
	std::string l_strLog;
	if (l_bResult)
		l_strLog = "Ok ";
	else
		l_strLog = "Error ";
	l_strLog += l_strBehaviorMessage;
	FMLog::LogWithFlag(l_strLog.c_str(), LOG_ID_NETWORK, true);
	return true;
}

bool cNetworkBrain::AdminAuthorityAndTargetUserCheck(const char * e_strAdminID, const char * e_strTargetID, FATMING_CORE::sNetworkReceivedPacket * e_pNetworkReceivedPacket,const char*e_strPrefixMessage)
{
	GET_USER_VECTOR_INSTANCE_AND_DO_MUTEX(l_pUserVector);
	auto l_pNewUser = l_pUserVector->GetObject(e_strTargetID);
	auto l_pAdminUser = l_pUserVector->GetObject(e_strAdminID);
	auto l_pSocketAdminNewUser = l_pUserVector->GetActivedConnectedUser(e_pNetworkReceivedPacket->pReceivedSocket);
	std::string l_strBehaviorMessage = UT::ComposeMsgByFormat("admin ID %s target ID %s", e_strAdminID, e_strTargetID);
	if (l_pAdminUser != l_pSocketAdminNewUser)
	{
		std::string l_strLog = "Error User socket and ID is not same:";
		l_strLog += e_strPrefixMessage;
		l_strLog += l_strBehaviorMessage;
		FMLog::LogWithFlag(l_strLog.c_str(), LOG_ID_NETWORK, true);
		return false;
	}
	std::string l_strAuthorityMessage;
	if (!cUserVector::AdminAuthorityAndTargetUserCheck(l_pUserVector,l_pAdminUser, e_strTargetID, l_strAuthorityMessage))
	{
		std::string l_strLog = "Error:";
		l_strLog += l_strAuthorityMessage;
		l_strLog += e_strPrefixMessage;
		l_strLog += ",";
		l_strLog += l_strBehaviorMessage;
		FMLog::LogWithFlag(l_strLog.c_str(), LOG_ID_NETWORK, true);
		return false;
	}
	return true;
}
