#pragma once
#include "FishDBStructer.h"
enum eEventMessage
{
	eEM_MONGODB_INITIALIZE_START = 0,
	eEM_MONGODB_INITIALIZE_FINISH,
	eEM_MONGODB_CURD,//eDB_CURD_Type
	eEM_Max,
};